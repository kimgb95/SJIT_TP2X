

#ifndef _HQADLL_H_
#define _HQADLL_H_

#ifdef _AP
#include "pcap.h"
#endif


typedef struct _EFUSE_SETTINGS {
    USHORT ChipID;
    UCHAR  TxPower0;
    UCHAR  TxPower1;
    USHORT FrequencyOffset;
    UCHAR  Tssi;
    UCHAR  ePA;
    UCHAR  TempComp;//enable or disable
    UCHAR  TxPower0_Band1;
    UCHAR  reserved[15];
} EFUSE_SETTINGS, * PEFUSE_SETTINGS;

//for IoT/Indium SLT
typedef struct _UART_CFG_STRUC {
    UINT32        ComPortNumber;
    UINT32        BaudRate;
    UINT32      HasDownloaded;
}UART_CFG_STRUC, * PUART_CFG_STRUC;

typedef struct RX_STASTIC {
    UINT32 FCSErr_CCK;
    UINT32 FCSErr_OFDM;
    UINT32 CCK_PD;
    UINT32 OFDM_PD;
    UINT32 CCK_SIG_Err;
    UINT32 CCK_SFD_Err;
    UINT32 OFDM_SIG_Err;
    UINT32 OFDM_TAG_Err;
    ULONG WB_RSSI0;
    ULONG IB_RSSI0;
    ULONG WB_RSSI1;
    ULONG IB_RSSI1;
    UINT32 PhyMdrdyCCK;
    UINT32 PhyMdrdyOFDM;
    UINT32 DriverRxCount;
    UINT32 RCPI0;
    UINT32 RCPI1;
    UINT32 FreqOffsetFromRX;
    UINT32 RSSI0;
    UINT32 RSSI1;//insert new member here
    UINT32 ACI_hit : 1;
    UINT32 FAGC_Rssi_IB_R0 : 8;
    UINT32 FAGC_Rssi_WB_R0 : 8;
    UINT32 ReservedBit : 15;
    UINT32 Reserved[7];
    UINT32 MACMdrdy;
    UINT32 RXOK;
    float PER;
}RX_STASTIC, * PRX_STASTIC;

typedef struct {
    UCHAR iPage;
    UCHAR iArrival;
    UCHAR iValid;
    UCHAR MAC[6];
    UCHAR incol;
    UCHAR incow;
    UCHAR icw;
    UCHAR ing;
    UCHAR timeout;
} PFMU_TAG_3883, * pPFMU_TAG_3883;


int WINAPI HQA_SetDeviceType(int iDeviceType);//if you don't assign, DLL will detect it automatically.
int WINAPI HQA_GetSelectDeviceType();
//==============================================================================//
// HQA Export Function
//==============================================================================//
// 1. Init Adapter
int WINAPI HQA_SetDriverIndex(int iIndex);
int WINAPI HQA_OpenAdapter();
int WINAPI HQA_OpenAdapterWithoutDownload();

int WINAPI HQA_SUSPEND();
int WINAPI HQA_RESUME();

int WINAPI HQA_ASIC_TOPInit();//no use
int WINAPI HQA_ASIC_MACInit();//no use

int WINAPI HQA_InitValue();
int WINAPI HQA_CloseAdapter();
int WINAPI HQA_RadioOn();
int WINAPI HQA_RadioOff();

int WINAPI HQA_GetInterface(ULONG *DeviceInterFace);
int WINAPI HQA_GetDllVersion(char *DllVersion);
int WINAPI HQA_GetEEPROMBinVersion(PUSHORT Version);
int WINAPI HQA_GetFWBuildDate(char *);
int WINAPI HQA_FWDownload(char *pFWPath);
int WINAPI HQA_GetFWInfo(char* info,int *len);
int WINAPI HQA_GeteFuseSettings(EFUSE_SETTINGS *Psetting);
DWORD WINAPI HQA_GetChipID();
DWORD WINAPI HQA_GetChipVersion();
int WINAPI HQA_N9OnOffCal(ULONG times);
int WINAPI HQA_CM4N9Sleep(BOOL is_cm4, BOOL sleep_in);

/**
 * @brief Read data from eFuse which data should be stored in the dataBuf
 *
 * @param addr      The eFuse address, should be the offset value, like: A20A0414, the offset should be 0x414
 * @param dataBuf   The read response data to store.
 * @return int When operate succeed, return TRUE; otherwise, return FALSE
 */
int WINAPI HQA_ReadEfuseExt(ULONG addr, ULONG *dataBuf);

/**
 * @brief Write data to eFuse according to the address.
 *
 * @param addr      The eFuse address, should be the offset value.
 * @param dataBuf   The value which wish to write to the eFuse.
 * @return int When operate succeed, return TRUE; otherwise, return FALSE.
 */
int WINAPI HQA_WriteEfuseExt(ULONG addr, ULONG dataBuf);


int WINAPI HQA_Reboot();
// 2. Tx/Rx Test
int WINAPI HQA_StartTx(ULONG PacketCount/*TxCount*/,
                                    USHORT PacketSize/*TxLength*/);
int WINAPI HQA_StartTxExt(void* TxFrames);
int WINAPI HQA_StartContiTxTone(int iType=0);//tx tone//7603,7628
int WINAPI HQA_SetTXTonePower(int dec0,int dec1);//dec0 is 1 db ,dec 1 is 0.25db//MT7603 only now
//dec0 input 0~F, dec1 -32~31
int WINAPI HQA_StartContiTxToneExt(UCHAR AntennaIdx,UCHAR ToneType,UCHAR ToneFreq,int iDCIOffset,int iDCOOffset);//tx tone//7636
int WINAPI HQA_StopContiTxTone();


//WFSelect: 7603,7628
//#define WF_0            0
//#define WF_1            1
//#define WF_ALL        2
//WFSelect: 7636o
//#define WF_0            1
//#define WF_1            2
//#define WF_ALL        3
int WINAPI HQA_StartContinusTx(ULONG Modulation, ULONG BW, ULONG pri_ch, ULONG rate,ULONG WFSelect);//ContiTx(continous tx)//7603,7628,7636 use the same function
int WINAPI HQA_StartContiTx(int iType=0);//no use now
int WINAPI HQA_StartTxCarrier();
int WINAPI HQA_StartRx();
int WINAPI HQA_StopTx();
int WINAPI HQA_StoptContiTx();
int WINAPI HQA_StopTxCarrier( );
int WINAPI HQA_StopRx();
int WINAPI HQA_SetTxPath(UCHAR TxPath);
int WINAPI HQA_SetRxPath(UCHAR RxPath);
int WINAPI HQA_SetTxIPG(ULONG TxIPG);//(AIFS)
int WINAPI HQA_SetTxPacketTime(ULONG iSlotTime,ULONG iSifsTime);//(AIFS)
//int WINAPI HQA_SetTxPower0(ULONG ModulationSystem,ULONG ModulationType,CHAR TxPower0);
int WINAPI HQA_SetTxPower0(CHAR TxPower0);
int WINAPI HQA_SetTxPower1(CHAR TxPower1);
int WINAPI HQA_SetTxPowerExt(ULONG TxPower, ULONG BAND, ULONG Channel, ULONG ChannelBand, ULONG WFSelect);

/**
 * For single SKU feature
 * If enable is true, Read single sku data from single_sku.bin file to configure the device
 * If enable is false, the single sku data is 0 to disable single sku feature
 * Write the content to ATED which should transfer to N9
 * Wait for the response from N9
 * */
int WINAPI HQA_SetTxPowerForSingleSKU(BOOL enable);

/**
 * For single SKU feature
 * Use to check the QA Tool support single sku feature or not
 * */
int WINAPI HQA_IsSupportSingleSku();


int WINAPI HQA_SetTxPowerExtV2(ULONG TxPower, ULONG BAND, ULONG Channel1, ULONG ChannelBand1,
    ULONG Channel2, ULONG ChannelBand2, ULONG WFSelect, ULONG *pReserved1, ULONG *Reserved2, ULONG *pReserved3, ULONG *pReserved4);


int WINAPI HQA_AntennaSel(UCHAR AntSel);
/*
#define MainAnt        0
#define AuxAnt         1
*/

int WINAPI HQA_AntennaSelExt(ULONG Band,ULONG RFPortMask,ULONG RFPort,ULONG AntPort, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);

int WINAPI HQA_GetTXPayloadInfo(PULONG TXPaylodLength, PUCHAR TXPayload);
int WINAPI HQA_SetUSBTxAggregate(BOOL bAggregate);
int WINAPI HQA_SetUSBTxAggregateCount(int AggregateCount);
int WINAPI HQA_GetGetRXMPDU(UCHAR* buffer, ULONG bufsize);
int WINAPI HQA_SetTxPattern(DWORD TxPattern);
int WINAPI HQA_SetTxPatternInc(BOOL TxPatternInc);
int WINAPI HQA_SetTxPatternRandom(BOOL TxPatternRandom);
int WINAPI HQA_SetTxPayload(void* TxFramesExt);
int WINAPI HQA_SetSTBC(BOOL bEnable);
int WINAPI HQA_SetShortGI(BOOL bEnable);
int WINAPI HQA_SetRXMACAddr(UCHAR* pAddr);

int WINAPI HQA_SetDestMacAddr(UCHAR* pAddr);//destination MAC
int WINAPI HQA_SetDeviceMacAddr(UCHAR* pAddr);//own MAC
// 3. Channel/Preamble/Rate/... setting
//int WINAPI HQA_SetChannelInfo(CMD_CH_PRIVILEGE_T ChannelInfo);//7603
int WINAPI HQA_SetChannel(UCHAR Channel);
int WINAPI HQA_SetReason(UCHAR reason);
int WINAPI HQA_SetPreamble(UCHAR Preamble);
int WINAPI HQA_SetRate(UCHAR McsRate);
int WINAPI HQA_SetNss(UCHAR Nss);
int WINAPI HQA_SetSystemBW(UCHAR SysBW);
int WINAPI HQA_SetPerPktBW(UCHAR PerPktBW);
int WINAPI HQA_SetPrimaryBW(UCHAR PrimaryBW);
int WINAPI HQA_SetFreqOffset(UCHAR FreqOffset);
int WINAPI HQA_SetAutoResponder(UCHAR AutoRsp);
int WINAPI HQA_SetTssiOnOff(UCHAR TssiOnOff);//ATEAUTOALC(for iPAenable TSSI)
int WINAPI HQA_SetTssiOnOffExt(UCHAR TssiOnOff,int WFSelect);
int WINAPI HQA_SetRx_H_L_Temperature(UCHAR CompersationOnOff);
int WINAPI HQA_SetRadioMode(BOOL bRadioMode);
int WINAPI HQA_SetDPD(BOOL bOnOff,int WFSelect);
int WINAPI HQA_SetLDPC(BOOL bEnable);

// 4. Statistics Counter
int WINAPI HQA_GetRXStatisticsAll(RX_STASTIC *pData);//werner 7603
int WINAPI HQA_GetRXStatisticsAllExt(ULONG Action,ULONG InData,ULONG *pOutData, float *pFloatValue,int *pValue);//werner 7615
/*
typedef enum _ENUM_GET_RXINFO_TYPE {
    RXINFO_UPDATE = 0,
    RXINFO_GET_PER0,
    RXINFO_GET_RXOK0,
    RXINFO_GET_MAC_FCS_ERR0,
    RXINFO_GET_MAC_MDRDY0,
    RXINFO_GET_PER1,
    RXINFO_GET_RXOK1,
    RXINFO_GET_MAC_FCS_ERR1,
    RXINFO_GET_MAC_MDRDY1,
    RXINFO_GET_FCS_ERR_CCK,
    RXINFO_GET_FCS_ERR_OFDM,
    RXINFO_GET_CCK_PD,
    RXINFO_GET_OFDM_PD,
    RXINFO_GET_CCK_SIG_ERR,
    RXINFO_GET_CCK_SFD_ERR,
    RXINFO_GET_OFDM_SIG_ERR,
    RXINFO_GET_OFDM_TAG_ERR,
    RXINFO_GET_WB_RSSI0,
    RXINFO_GET_WB_RSSI1,
    RXINFO_GET_IB_RSSI0,
    RXINFO_GET_IB_RSSI1,
    RXINFO_GET_PHY_MDDY_CCK,
    RXINFO_GET_PHY_MDDY_OFDM,
    RXINFO_GET_DRIVER_RX_COUNT0,
    RXINFO_GET_DRIVER_RX_COUNT1,
    RXINFO_GET_RCPI0,
    RXINFO_GET_RCPI1,
    RXINFO_GET_RCPI2,
    RXINFO_GET_RCPI3,
    RXINFO_GET_RSSI0,
    RXINFO_GET_RSSI1,
    RXINFO_GET_RSSI2,
    RXINFO_GET_RSSI3,
    RXINFO_GET_SNR0,
    RXINFO_GET_SNR1,
    RXINFO_GET_SNR2,
    RXINFO_GET_SNR3,
    RXINFO_GET_FREQ_OFFSET_FROMRX,
    RXINFO_GET_FAGC_RSSI_IB_R0,
    RXINFO_GET_FAGC_RSSI_IB_R1,
    RXINFO_GET_FAGC_RSSI_IB_R2,
    RXINFO_GET_FAGC_RSSI_IB_R3,
    RXINFO_GET_FAGC_RSSI_WB_R0,
    RXINFO_GET_FAGC_RSSI_WB_R1,
    RXINFO_GET_FAGC_RSSI_WB_R2,
    RXINFO_GET_FAGC_RSSI_WB_R3,

    RXINFO_GET_INST_RSSI_IB_R0,
    RXINFO_GET_INST_RSSI_IB_R1,
    RXINFO_GET_INST_RSSI_IB_R2,
    RXINFO_GET_INST_RSSI_IB_R3,

    RXINFO_GET_INST_RSSI_WB_R0,
    RXINFO_GET_INST_RSSI_WB_R1,
    RXINFO_GET_INST_RSSI_WB_R2,
    RXINFO_GET_INST_RSSI_WB_R3,
    RXINFO_GET_ACI_HIT_LOWER,
    RXINFO_GET_ACI_HIT_UPPER,
    RXINFO_GET_OUTOF_RESOURCE0,
    RXINFO_GET_OUTOF_RESOURCE1,
    RXINFO_GET_ALL_LENGTH_MISMATCH_B0,
    RXINFO_GET_ALL_LENGTH_MISMATCH_B1,
    RXINFO_GET_CCK_PD_B1,
    RXINFO_GET_OFDM_PD_B1,
    RXINFO_GET_CCK_SIG_ERR_B1,
    RXINFO_GET_CCK_SFD_ERR_B1,
    RXINFO_GET_OFDM_SIG_ERR_B1,
    RXINFO_GET_OFDM_TAG_ERR_B1,
    RXINFO_GET_PHY_MDDY_CCK_B1,
    RXINFO_GET_PHY_MDDY_OFDM_B1,
    RXINFO_GET_FCS_ERR_CCK_B1,
    RXINFO_GET_FCS_ERR_OFDM_B1,
    RXINFO_GET_MURXCOUNT,
} ENUM_GET_RXINFO_TYPE, *P_ENUM_GET_RXINFO_TYPE;
*/

int WINAPI HQA_GetRCPI(ULONG *pRCPI0,ULONG *pRCPI1);//werner 7603

int WINAPI HQA_ResetTxRxCounter();
int WINAPI HQA_GetStatistics(CHAR StatisticsBuffer[], int BufferSize);
int WINAPI HQA_GetRxOKData(ULONG *RxOKDataPacket);
int WINAPI HQA_GetRxIBRSSI(ULONG *RxIBRSSIValue);
int WINAPI HQA_GetRxOKOther(ULONG *RxOKOtherPacket);
int WINAPI HQA_GetRxAllPktCount(ULONG *RxPacketcount);
int WINAPI HQA_GetTxTransmitted(ULONG *TxTransmittedCounter);
int WINAPI HQA_GetTxInfo(ULONG Action,ULONG InInfo,ULONG *pOutInfo);//7615
/*
typedef enum _ENUM_GET_TXINFO_TYPE {
    TXINFO_UDATE = 0,
    TXINFO_GET_TRANSMITTED_BADN0,
    TXINFO_GET_TRANSMITTED_BADN1,
} ENUM_GET_TXINFO_TYPE, *P_ENUM_GET_TXINFO_TYPE;
*/


int WINAPI HQA_GetHwCounter(ULONG *FcsErr, ULONG *RxOverflow, ULONG *PhyErr, ULONG *FalseCCA);

int WINAPI HQA_CalibrationOperation(ULONG CalibrationID, ULONG* Parameter, ULONG ParameterSize);
int WINAPI HQA_CalibrationTestMode(ULONG Mode);//1:test mode, 0,normal mode
int WINAPI HQA_CalibrationRobustTest(ULONG CalibrationID,ULONG Repeat);
int WINAPI HQA_CalibrationRobustTestExt(ULONG CalibrationID,ULONG Repeat,ULONG band,ULONG reserved0,ULONG reserved1,ULONG reserved2);//for MT7615
int WINAPI HQA_CalibrationBypass(ULONG Item);
int WINAPI HQA_CalibrationBypassExt(ULONG Item, ULONG Band, ULONG Reserve0, ULONG Reserve1, ULONG Reserve2);
// 5. MAC/BBP/RF Register Access
int WINAPI HQA_MacRegReadAuto(ULONG Offset, ULONG* Data);//PCIe or USB addr
int WINAPI HQA_MacRegWriteAuto(ULONG Offset, ULONG Data);//PCIe or USB addr
int WINAPI HQA_MacRegRead(ULONG Offset, ULONG* Data);
int WINAPI HQA_MacRegWrite(ULONG Offset, ULONG Data);
int WINAPI HQA_MacRegBulkRead(ULONG Offset, ULONG* Data, ULONG Length);
int WINAPI HQA_BbpRegRead(ULONG Offset, ULONG* Data);
int WINAPI HQA_BbpRegWrite(ULONG Offset, ULONG Data);
int WINAPI HQA_RfRegRead(UCHAR Bank, UCHAR Id, UCHAR *Data);//not used now
int WINAPI HQA_RfRegWrite(UCHAR Bank, UCHAR Id, UCHAR Data);//not used now
int WINAPI HQA_RfRegReadV2(ULONG WfSel, ULONG offset, ULONG *Data);
int WINAPI HQA_RfRegBulkReadV2(ULONG WfSel, ULONG offset, ULONG *Data, ULONG Length);
int WINAPI HQA_RfRegWriteV2(ULONG WfSel, ULONG offset, ULONG Data);
int WINAPI HQA_MultiRWCR(ULONG CRConut,ULONG *ptype, ULONG *pRFSelect, ULONG *pisWrite, ULONG *pCRAddress, ULONG *pCRValue);
//CRConut: how many CR number, type 0:MAC ,1:RF, pisWrite 0:read, 1:write
//only support MAC write now

int WINAPI HQA_ExternalRegisterSetting(void);
int WINAPI HQA_SetScriptFileName(char *filename);

// 6. EEPROM/eFuse
BOOL WINAPI  HQA_eFusePhysicalWrite(DWORD dWData0, DWORD dWData1,DWORD dWData2,DWORD dWData3,DWORD dAddr);//write whole block 16 byte
BOOL WINAPI  HQA_eFusePhysicalWrite1(DWORD dWData0, USHORT Length,DWORD dAddr);//write 0~4byte
BOOL WINAPI HQA_eFuseLogicalWrite(USHORT Offset, USHORT Length, USHORT* pData);

BOOL WINAPI  HQA_eFusePhysicalRead(DWORD *dWData0, DWORD *dWData1,DWORD *dWData2,DWORD *dWData3,DWORD dAddr);//read whole block 16 byte
BOOL WINAPI  HQA_eFusePhysicalRead1(DWORD *dWData0, DWORD dAddr);
int WINAPI  HQA_eFuseLogicalRead(DWORD *dWData0, DWORD *dWData1,DWORD *dWData2,DWORD *dWData3,DWORD dAddr);//read whole block 16 byte
int WINAPI  HQA_eFuseLogicalRead1(DWORD *dWData0, DWORD dAddr);


int WINAPI HQA_ReadEEPROM(USHORT Offset, USHORT Length, PUSHORT Data);//length2, or 16//If support bulk, Offset must be even
int WINAPI HQA_WriteEEPROM(USHORT Offset, USHORT Length, PUSHORT Data);//length2, or 16
int WINAPI HQA_CheckEfuseMode(BOOL *bEfuseMode);//only use bit0, : 0:eeprom mode, 1:eFuse
int WINAPI HQA_CheckefuseModeType(DWORD *ModeType);
int WINAPI HQA_CheckefuseeNativModeType(DWORD *ModeType);
/*
typedef enum _WRITE_BUFFER_DONE_TARGET {
    E2P_UNKNOW_MODE =0,
    E2P_EFUSE_MODE = 1,
    E2P_FLASH_MODE,
    E2P_EEPROM_MODE,
    E2P_BIN_MODE
} WRITE_BUFFER_DONE_TARGET, *PWRITE_BUFFER_DONE_TARGET;


*/

int WINAPI HQA_GetFreeEfuseBlock(PUCHAR FreeBlkNum);
int WINAPI HQA_GetEfuseBlockNr(PUSHORT pEfusueBlockNr);
int WINAPI HQA_WriteEFuseFromBuffer();
//int WINAPI HQA_SetIpg(ULONG TxIpg);
int WINAPI HQA_SetTxAddr(void *TxFrames);
int WINAPI HQA_CopyToEfuseBuffer(UCHAR *pEEprom,int iLength);//copy the buffer which you want to write to efuse
int WINAPI HQA_TMRSetting(ULONG Type);
int WINAPI HQA_TMRSettingExt(ULONG Type, ULONG version, ULONG MPThroughHold, ULONG MPLter, ULONG reserved0, ULONG reserved1, ULONG reserved2);


// 7. Temperature compensation
int WINAPI HQA_ReadTempReferenceValue(PCHAR pTempRefValue);
int WINAPI HQA_SetAutoALC(UCHAR HqaAutoALC);

/****************************************/
// 8. IQ compensation
/****************************************/
int WINAPI HQA_ApplyIQCompensation(BOOL ApplyIQCompensation);

/****************************************/
// 8. RDD
/****************************************/
int WINAPI HQA_RDDTest(int iAction);//0:stop 1:start //RDD ATE
int WINAPI HQA_RDDStart();
int WINAPI HQA_RDDStop();

int WINAPI HQA_RDDTestExt(int iAction,ULONG RDDNum,ULONG RxInSel);//MT7615 0:stop 1:start //RDD ATE
int WINAPI HQA_RDDStartExt(ULONG RDDNum,ULONG RxInSel);
int WINAPI HQA_RDDStopExt(ULONG RDDNum,ULONG RxInSel);
int WINAPI HQA_RDDStartExtATE(ULONG RDDNum,ULONG RxInSel);
int WINAPI HQA_RDDStopExtATE(ULONG RDDNum,ULONG RxInSel);
/****************************************/
//        Other
/****************************************/
int WINAPI HQA_GetThermalValue(DWORD *ThermalValue);//7636 slt
int WINAPI HQA_GetThermalCRValue(DWORD *ThermalCRValue);
/****************************************/
//        HIF Test
/****************************************/
int WINAPI HQA_HIFTestSetStartLoopback(ULONG StartLength,ULONG EndLength);
int WINAPI HQA_HIFTestSetStopLoopback();
int WINAPI HQA_HIFTestSetUseDefaultPattern(BOOL isUseDefaultPattern);
int WINAPI HQA_HIFTestSetRepeatTime(ULONG iRepeatTime);
int WINAPI HQA_HIFTestSetUSBParameter(ULONG BulkOutNum,ULONG BulkInNum);//also can set PCie ring
int WINAPI HQA_HIFTestSetAggParameter(ULONG AggPacketNumber, ULONG RXAggEnable, ULONG RXAggpktLmt, ULONG RXAggLmt, ULONG RXAggpTO);
int WINAPI HQA_HIFTestGetStatus(ULONG *pFailReason,ULONG *pTxPktCount,ULONG *pRxPktCount, ULONG *pTxByteCount,ULONG *pRxByteCount, ULONG *pLastBulkOut);
int WINAPI HQA_HIFTestGetTxRxData(UCHAR *pTXData,ULONG *pTXDataLen,UCHAR *pRXData,ULONG *pRXDataLen);
int WINAPI HQA_HIFTestSetTxRxData(UCHAR *pTXData,ULONG TXDataLen,UCHAR *pRXData,ULONG RXDataLen);
int WINAPI HQA_UDMAAction(UCHAR Action);//UDMA_STOP = 0, UDMA_START = 1
/****************************************/
// 9. ATE mode API
/****************************************/
int WINAPI HQA_SetATEMode(BOOL bATEMode);
int WINAPI HQA_SetForceLoadEE(BOOL bForceLoadEE);
int WINAPI HQA_ReinitEepromSetting();
int WINAPI HQA_GetInitialTemperature(PCHAR pInitTemperature);
int WINAPI HQA_TSSI_DC_Cal(PCHAR tssi_dc0);
int WINAPI HQA_ThermoCal(UCHAR IsEnable, UCHAR PeriodTrigger, UCHAR TempDiffTrigger, UCHAR Reserve1, UCHAR Reserve2);
int WINAPI HQA_SaveEEPromBuffer(CHAR *pPath);
//E2P_EFUSE_MODE,E2P_FLASH_MODE,E2P_EEPROM_MODE,E2P_BIN_MODE
int WINAPI HQA_WriteBufferDone(ULONG Target);//write buffer to efuse,flash,or....   //windows driver only support efuse now.
/****************************************/
// 10. SLT test
/****************************************/
int WINAPI HQA_GetRxU2MData(ULONG *RxU2MDataPacket);
int WINAPI HQA_SecuritySetting(PUCHAR PeerMAC, UCHAR CipherAlg);
int WINAPI HQA_SecuritySettingExt(void *pSetting);
int WINAPI HQA_GetCurrentAddr(UCHAR* Addr);
int WINAPI HQA_SetSLTMode(BOOL bSLTMode);
int WINAPI HQA_GetRxRSSI(LONG *RxRSSI);

int WINAPI HQA_SetGetCollectRSSINum(int iCollectnum);//for SLT
int WINAPI HQA_GetCollectRSSIAvg(int *ipSize,int *ipRSSI);//ipSize retur how many rx will report. for SLT
//return first ipRSSI is rssi0 avg, rssi0 var,rssi1 avg, rssi1 var,...
//if input size is not enough(ipNum), API will return 0 and *ipNum = -1

//int WINAPI HQA_GetRxSNR(double *RxSNR);
int WINAPI HQA_GetRxSNR(int *RxSNR0,int *RxSNR1);
int WINAPI HQA_GetRSSI(int *RxRSSI0,int *RxRSSI1);
int WINAPI HQA_SetTXRXLoopback(BOOL LoopbackMode,int iRingOrPipe);
int WINAPI HQA_CalibrationResultDump(int iType,BOOL bCheckResult);
int WINAPI HQA_GetSecurityResult(ULONG *piType);
int WINAPI HQA_SetLoadBufferbinFileName(CHAR *pFileName);
int WINAPI HQA_GetSensorResult(DWORD *iResult,int iLog);
int WINAPI HQA_CalDump(UCHAR isEnable);//MT7636
int WINAPI HQA_WIFIPowerOff(UCHAR isEnable);//MT7636 send FW cmd
/****************************************/
// 11. FW Packet command
/****************************************/
int WINAPI HQA_SetSideBandOption(BOOL bSideBandOption);
int WINAPI HQA_FWPacketCMD_AccessReg(ULONG address,ULONG *setData,BOOL bIsSet);//BOOL IsSet,0:Query, 1:set.

int WINAPI HQA_FWPacketCMD_WriteReg(ULONG address,ULONG setData);//call HQA_FWPacketCMD_AccessReg
int WINAPI HQA_FWPacketCMD_ReadReg(ULONG address,ULONG *setData);//call HQA_FWPacketCMD_AccessReg

int WINAPI HQA_FWPacketCMD_AccessWF(ULONG address,ULONG *setData,BOOL bIsSet,int WF_Number);//BOOL IsSet,0:Query, 1:set.

//APSOC QA_RfRegBulkWrite/QA_RfRegBulkRead// windows driver only support single CR access
int WINAPI HQA_FWPacketCMD_AccessEEPROM(ULONG address,ULONG *setData,BOOL bIsSet,int iLength);//BOOL IsSet,0:Query, 1:set.
int WINAPI HQA_FWPacketCMD_AccessEfuse(ULONG address,ULONG *setData,BOOL bIsSet,int iLength);//BOOL IsSet,0:Query, 1:set.
int WINAPI HQA_FWPacketCMD_ClockSwitchDisable(UCHAR disable);//disable: 1 disable clock switch,    disable: 0 enable clock switch

int WINAPI HQA_BF_load3883TXT(CHAR *pFileName);
int WINAPI HQA_BF_Create3883TXT(CHAR *pFileName,int nTx, int nRx);



//}//extern C
#ifdef _AP
/****************************************/
// AP SOC
/****************************************/
int WINAPI HQA_SetINicMode();
int WINAPI HQA_SetStandaloneMode();
int WINAPI HQA_SetBuffermodeOrEeprom();
int WINAPI HQA_Setefuse();
int WINAPI HQA_SetOpenAdapter(char *AdapterName);
int WINAPI HQA_FineAllAdapter(pcap_if_t **alldevs);
int WINAPI HQA_FreeAllAdapter(pcap_if_t *alldevs);
int WINAPI HQA_GetMACaddress(pcap_if_t *g_Select_adapter, UCHAR* g_Select_MAC);
int WINAPI HQA_SetAPSOCCmdDestMacAddr(UCHAR *pMac);
#endif

//FFT
//FFT Control
//int WINAPI HQA_FFTStartCapture(ULONG channel,ULONG bw,ULONG rxPath,ULONG Type/*ADC or IQC*/,
//    ULONG IsTriggerMode,ULONG DomainType,ULONG GoldenUnit);
int WINAPI HQA_ShowFFTCaptureDialog(ULONG iShow);
//
int WINAPI HQA_EnableFFTCapture(ULONG Type);

/****************************************/
// 3883 AP SOC
/****************************************/
int WINAPI HQA_3883_SetChannel(ULONG channel);//Set channel UI
int WINAPI HQA_3883_SetPreamble(ULONG preamble);//Set channel UI
int WINAPI HQA_3883_SetRate(ULONG Rate);//Set channel UI
int WINAPI HQA_3883_SetBW(ULONG BW);//Set BW UI
int WINAPI HQA_3883_StartRx();//Set BW UI

int WINAPI HQA_3883_StartTX(ULONG iTXCount); //UI
int WINAPI HQA_3883_StopTX(); //UI
int WINAPI HQA_3883_GoldenStartTX(USHORT channel,USHORT phyMode,USHORT MCS,USHORT BW,USHORT TXAnt,USHORT TXleng,USHORT TXCount,USHORT TxPayload);
int WINAPI HQA_3883_GoldenStopTX();
int WINAPI HQA_3883_SetTXPath(ULONG TxPath);//UI
int WINAPI HQA_3883_SeteBFEnable(ULONG isEnable);//UI
int WINAPI HQA_3883_SetTXPower(ULONG Power0,ULONG Power1,ULONG Power2);//UI
int WINAPI HQA_3883_BFQueryTag(USHORT ProfileNumber,BOOL isITag,UCHAR *pTagValue);//isITag:1 I TAG,  isITag:0 E TAG
int WINAPI HQA_3883_BFWriteTag(USHORT ProfileNumber,BOOL isITag,UCHAR *pProfileData,UCHAR Datalen);//isITag:1 I TAG,  isITag:0 E TAG
int WINAPI HQA_3883_BFWriteTagByStructure(USHORT ProfileNumber,BOOL isITag,PFMU_TAG_3883 TagData);//isITag:1 I TAG,  isITag:0 E TAG
int WINAPI HQA_3883_SetTXPower0(USHORT Power);
int WINAPI HQA_3883_SetTXPower1(USHORT Power);
int WINAPI HQA_3883_SetTXPower2(USHORT Power);

int WINAPI HQA_3883_BFQueryProfile(USHORT ProfileNumber,SHORT StartCarrier,USHORT NoOfCarriers,BOOL isITag,UCHAR *pProfileValue);//isITag:1 I TAG,  isITag:0 E TAG
int WINAPI HQA_3883_BFWriteProfile(USHORT ProfileNumber,SHORT StartCarrier,BOOL isITag,UCHAR *pProfileData,UCHAR Datalen);//isITag:1 I TAG,  isITag:0 E TAG
int WINAPI HQA_3883_TXBFGoldenInit(USHORT Channel,PUSHORT pPower0,PUSHORT pPower1,PUSHORT pPower2);
int WINAPI HQA_3883_TXBFEnable(USHORT Enable);
int WINAPI HQA_3883_TXBFGoldenTxInit(USHORT Channel, USHORT PHYMode, USHORT BW, USHORT MCS, USHORT TxAnt);
int WINAPI HQA_3883_TXBFTriggerSounding(USHORT Channel, USHORT SoundingType, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT TxAnt, USHORT RxAnt, USHORT TxCount, USHORT TxPower0, USHORT TxPower1, USHORT TxPower2);
int WINAPI HQA_3883TXBFProfileTagValid(UCHAR validFlg,UCHAR profileIdx);//3883 beamformer is 0
//BeamForming for ATE
int WINAPI HQA_eBFATETestRX(USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount);//3883 vs 7636
int WINAPI HQA_eBFATEInitBeamFormer(USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount);//7636 vs 7636
int WINAPI HQA_eBFATEInitBeamFormee(USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount);//7636 vs 7636

int WINAPI HQA_iBFATEInitBeamFormer(USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount);//7636 vs 7636
int WINAPI HQA_iBFATEInitBeamFormee(USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount);//7636 vs 7636

int WINAPI HQA_SetDevMACAddr(UCHAR *BFerMAC, UCHAR *BFeeMAC_0, UCHAR *BFeeMAC_1, UCHAR *BFeeMAC_2, UCHAR *BFeeMAC_3, USHORT nUser);
int WINAPI HQA_eBFATEInitBeamFormer_MT7615(USHORT Band,USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount,ULONG TxPower,ULONG Nc,ULONG Nr,ULONG PerPacketBW);//7615 vs 7615
int WINAPI HQA_eBFATEInitBeamFormee_MT7615(USHORT Band,USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount,ULONG TxPower,ULONG Nc,ULONG Nr,ULONG PerPacketBW);//7615 vs 7615

int WINAPI HQA_iBFATEInitBeamFormer_MT7615(USHORT Band,USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount,ULONG TxPower,ULONG Nc,ULONG Nr,ULONG PerPacketBW);//7615 vs 7615
int WINAPI HQA_iBFATEInitBeamFormee_MT7615(USHORT Band,USHORT Channel, USHORT PHYMode, USHORT MCS, USHORT BW, USHORT nT, USHORT nR, USHORT TxCount,ULONG TxPower,ULONG Nc,ULONG Nr,ULONG PerPacketBW);//7615 vs 7615
int WINAPI HQA_ProfileSetInvalid(USHORT PHYMode, USHORT DBW, USHORT nT, USHORT nR, USHORT BFType);


//BeamForming
int WINAPI HQA_TXBFProfileTagValid(UCHAR validFlg,UCHAR profileIdx);
int WINAPI HQA_TXBFerValid();
int WINAPI HQA_TXBFerUnValid();

int WINAPI HQA_TXBFProfileTagRead(UCHAR profileIdx,UCHAR *pOutBuffer,ULONG *plen);
//7636 output PFMU_PROFILE
int WINAPI HQA_TXBFProfileTagWrite(UCHAR profileIdx,UCHAR *pInBuffer,ULONG *plen);
//7636
int WINAPI HQA_TXBFProfileDataReadAll(UCHAR TxBfType,UCHAR profileIdx,UCHAR BW,UCHAR *pOutBuffer,ULONG *plen);
int WINAPI HQA_TXBFProfileDataRead(UCHAR profileIdx,UCHAR subCarrierIdx,UCHAR *pOutBuffer,ULONG *plen);
int WINAPI HQA_TXBFProfileDataWrite(UCHAR profileIdx,UCHAR subCarrierIdx,UCHAR *pInBuffer,ULONG *plen);
int WINAPI HQA_TXBFProfileDataWriteAll(UCHAR TxBfType,UCHAR profileIdx,UCHAR BW,UCHAR *pInBuffer,ULONG *plen);
int WINAPI HQA_ByPassMACCheckEnable(UCHAR isEnable);
int WINAPI HQA_BFTXPowerNormalizeEnable(UCHAR isEnable);
int WINAPI HQA_EnableITXBF(UCHAR isEnable);
int WINAPI HQA_EnableETXBF(UCHAR isEnable);
int WINAPI HQA_SetTXiBFProc(UCHAR isEnable);
int WINAPI HQA_SetTXeBFProc(UCHAR isEnable);//isEnable:true ,send trigger sounding        isEnable:false, stop send trigger sounding
int WINAPI HQA_IsPFMUChange(int BW,BOOL *isChange);

//MPS
int WINAPI HQA_MPSSetSeqData(DWORD Band,DWORD *pData,int DataLength);
/*
each data:4 bits reserved, 4bit mode, 16 bit tx path,8 bit MCS.
*/

int WINAPI HQA_MPSSetPayloadLength(DWORD Band,DWORD *pData,int DataLength);
int WINAPI HQA_MPSSetPacketCount(DWORD Band,DWORD *pData,int DataLength);
int WINAPI HQA_MPSSetPowerGain(DWORD Band,DWORD *pData,int DataLength);
int WINAPI HQA_MPSStart(DWORD Band);
int WINAPI HQA_MPSStop(DWORD Band);
int WINAPI HQA_MPSSetNss(DWORD Band,DWORD *pData,int DataLength);
int WINAPI HQA_MPSSetPerpacketBW(DWORD Band,DWORD *pData,int DataLength);

//DBDC  MT7615
int WINAPI HQA_SetBandMode(ULONG iBandMode,ULONG iBandType,ULONG reserved0,ULONG reserved1);
//iBandMode:typedef
/*typedef enum _BAND_MODE {
    BAND_MODE_SINGLE = 1,
    BAND_MODE_DBDC
} BAND_MODE, *PBAND_MODE;*/
//1 singleband
//2 dual band
//iBandType: onnly use while iBandMode=1 typedef
/*typedef enum _BAND_TYPE {
    BAND_TYPE_NO_THIS_BAND = 0,
    BAND_TYPE_2_4G,
    BAND_TYPE_5G,
    BAND_TYPE_2_4G_5G
} BAND_TYPE, *PBAND_TYPE;*/
//1 2.4G
//2 5G
int WINAPI HQA_GetBandMode(ULONG *piBandType,ULONG *pReserved);
/*
return iBandType
(each bit present a band type)
typedef enum _BAND_TYPE {
    BAND_TYPE_NO_THIS_BAND = 0,
    BAND_TYPE_2_4G,
    BAND_TYPE_5G,
    BAND_TYPE_2_4G_5G
} BAND_TYPE, *PBAND_TYPE;
*/

int WINAPI HQA_DBDCStartTX(ULONG Band,ULONG PcaketCount, ULONG Preamble, ULONG Rate, ULONG Power, ULONG STBC, ULONG LDPC,ULONG iBF,
    ULONG eBF, ULONG WlanIdx, ULONG AIFS, ULONG isShortGI, ULONG TXPath, ULONG Nss, ULONG *pReserved0, ULONG *pReserved1, ULONG *pReserved2);
/*
Band:
0: band 0
1: band 1

PcaketCount: how mayn packet you want to send.
0: countinuous TX

Preamble:
0:PREAMBLE_CCK
1:PREAMBLE_OFDM
2:PREAMBLE_MIX_MODE
3:PREAMBLE_GREEN_FIELD
4:PREAMBLE_VHT

Rate: MCS value
CCK =   MCS=0;  LP  1 Mbps
        MCS=1;  LP  2 Mbps
        MCS=2;  LP  5.5 Mbps
        MCS=3;  LP 11 Mbps
        MCS=8;  SP  1 Mbps
        MCS=9;  SP  2 Mbps
        MCS=10; SP  5.5 Mbps
        MCS=11; SP 11 Mbps

OFDM 11g =   MCS=0;  6 Mbps
             MCS=1;  9 Mbps
             MCS=2; 12 Mbps
             MCS=3; 18 Mbps
             MCS=4; 24 Mbps
             MCS=5; 36 Mbps
             MCS=6; 48 Mbps
             MCS=7; 54 Mbps

HT  11n =  MCS=0;   6.5 Mbps
           MCS=1;   13 Mbps
           MCS=2;   19.5Mbps
           MCS=3;   26 Mbps
           MCS=4;   39 Mbps
           MCS=5;   52 Mbps
           MCS=6;  58.5 Mbps
           MCS=7;   65 Mbps
           MCS=8;   13 Mbps
           MCS=9;   26 Mbps
           MCS=10;  39 Mbps
           MCS=11;  52 Mbps
           MCS=12;  78 Mbps
           MCS=13; 104 Mbps
           MCS=14; 117 Mbps
           MCS=15; 130 Mbps

           MCS=16; 19.5 Mbps
           MCS=17; 39 Mbps
           MCS=18; 58.5 Mbps
           MCS=19; 78 Mbps
           MCS=20; 117 Mbps
           MCS=21; 156 Mbps
           MCS=22; 175.5 Mbps
           MCS=23; 195 Mbps
           MCS=24; 26 Mbps
           MCS=25; 52 Mbps
           MCS=26; 78 Mbps
           MCS=27; 104 Mbps
           MCS=28; 156 Mbps
           MCS=29; 208 Mbps
           MCS=30; 234 Mbps
           MCS=31; 260 Mbps
           MCS=32;   6 Mbps

VHT[]=     MCS=0;
           MCS=1;
           MCS=2;
           MCS=3;
           MCS=4;
           MCS=5;
           MCS=6;
           MCS=7;
           MCS=8;
           MCS=9;

Power: Power value

STBC: STBC enable/disable
1:enalble
0:disable

LDPC: LDPC enable/disable
1:enalble
0:disable

iBF: iBF enable/disable
1:enalble
0:disable

eBF: eBF enable/disable
1:enalble
0:disable

WlanIdx: Wlan index id. If you don't want to use BF, you can ignore this parameter. Just input 0.


AIFS: AIFS value

isShortGI: isShortGI enable/disable
1:enalble
0:disable


TXPath: Each bit present each antenna.
hex value
0x01: WF0
0x02: WF1
0x04: WF2
0x08: WF3

0x03: WF0 + WF1
0x05: WF0 + WF2
0x0F: WF0 + WF1 + WF2 + WF3
...

Nss:
1~4

*/

int WINAPI HQA_DBDCStopTX(ULONG Band, ULONG *pReserved0, ULONG *pReserved1, ULONG *pReserved2);

/*
Band:
0: band 0
1: band 1
*/

int WINAPI HQA_DBDCStartRX(DWORD Band,UCHAR *pMAC);
int WINAPI HQA_DBDCStartRXExt(DWORD Band, ULONG RxPath,UCHAR *pMAC, ULONG pReserved0, ULONG pReserved1, ULONG pReserved2);//add rx path//Band: band select 0~1, pMAC: poiniter to a MAC addr, device can send ack when MAC is correct.

/*
Band:
0: band 0
1: band 1

RxPath: Each bit present each antenna.
hex value
0x01: WF0
0x02: WF1
0x04: WF2
0x08: WF3

0x03: WF0 + WF1
0x05: WF0 + WF2
0x0F: WF0 + WF1 + WF2 + WF3
...


pMAC: set device MAC, if TX destiination address is match this address, device can reply mac automatically.


*/
int WINAPI HQA_DBDCTXTone(ULONG DBDCIdx,ULONG Band,ULONG Control, ULONG AntIndex,ULONG ToneType, ULONG ToneFreq,ULONG DcOffsetI,ULONG DcOffsetQ,
    ULONG Power1db,ULONG Power0_25Db, ULONG *Reserved0, ULONG *Reserved1);
/*
DBDCIdx:
0:Band0
1:Band1

Band:
2.4G
5G

Control:
0:stop tx tone
1:start tx tone

AntIndex:
0:WF0
1:WF1
2:WF2
3:Wf3

ToneType:
0:DC
1:5M
2:10M
3:20M
4:40M

DCOffsetI: -512~15535
DCOffsetQ: -512~15535
*/

int WINAPI HQA_DBDCContinuousTX(ULONG Band, ULONG Control, ULONG AntIndex,ULONG Modulation, ULONG BW,
    ULONG PriCH, ULONG Central, ULONG Rate, ULONG FdMode, ULONG *Reserved0, ULONG *Reserved1);
/*
Band:
0:Band0
1:Band1

Control:
0:stop Continuous TX
1:start Continuous TX

Modulation:
0:CCK
1:OFDM
2:MIX_MODE
3:GREEN_FIELD
4:VHT

BW:
0: BW20
1: BW40

AntIndex:
0:WF0
1:WF1
2:WF2
3:WF3

FdMode:
0x1: OFDM STF
0x2: OFDM LTF
0x3: Payload OFDM/CCK
0x4: CCK PI/2
0x5: CCK PI

*/

//if you don't want to send ack, you can set mac all zero
int WINAPI HQA_DBDCStopRX(DWORD Band);
//int WINAPI HQA_DBDCSetChannel(UCHAR *pInData, ULONG *pInDataLen);
int WINAPI HQA_DBDCSetChannel(ULONG Band,ULONG CenterChannel0,ULONG CenterChannel1/*(for 160nc)*/,ULONG SystemBW,ULONG PerpacketBW, ULONG PrimarySelect,
    ULONG Reason, ULONG ChannelBand, ULONG pReserved2);
/*
band:
0:band 0
1:band 1

CenterChannel0:
channel number

CenterChannel1:
channel number, only valid when SystemBW is set to 160NC
If you don't want to use 160NC, you can ignore this parameter.

SystemBW:
0:BANDWIDTH_20
1:BANDWIDTH_40    1
2:BANDWIDTH_80    2
3:BANDWIDTH_10    3
4:BANDWIDTH_5        4
5:BANDWIDTH_160C    5
6:BANDWIDTH_160NC    6

PerpacketBW:
0:BANDWIDTH_20
1:BANDWIDTH_40    1
2:BANDWIDTH_80    2
3:BANDWIDTH_10    3
4:BANDWIDTH_5        4
5:BANDWIDTH_160C    5
6:BANDWIDTH_160NC    6

PrimarySelect:
0~7

Reason:
typedef enum _ENUM_SWITCH_REASON {
    SWITCH_NORMAL_TXRX = 0,
    SWITCH_SCAN = 3,
    SWITCH_MCC
} ENUM_SWITCH_REASON, *P_ENUM_SWITCH_REASON;

*/

//int WINAPI HQA_DBDCSetTXContent(UCHAR *pInData, ULONG *pInDataLen);
int WINAPI HQA_DBDCSetTXContent(ULONG Band, ULONG FC, ULONG Dur, ULONG SeqID, ULONG RepeatRandomNormal, ULONG TxLength, ULONG PayloadLngth,
    UCHAR *pSourceAddr,UCHAR *pDestAddr,UCHAR *pBSSID,UCHAR *pPayloadContent, ULONG pReserved0, ULONG pReserved1, ULONG pReserved2);
/*
band:
0:band 0
1:band 1

FC: 2 byte value

Dur: 2 byte value

SeqID: 2 byte value

RepeatRandomNormal:
repeat:1
random:2

TxLength:
TX packet length

PayloadLength:
assign payload length for pPayloadContent

pPayloadContent: tx payload pointer

pSourceAddr:A1 address

pDestAddr: A2 address

pBSSID: A3 address

*/
//RepeatRandomNormal: 1 repeat, 2 random

int WINAPI HQA_SetCfgOnOff(ULONG Type, ULONG Control, ULONG band, ULONG Reservrd0, ULONG Reservrd1, ULONG Reservrd2);
int WINAPI HQA_GetCfgOnOff(ULONG Type, ULONG band, ULONG *pStstus, ULONG *pReservrd1, ULONG Reservrd1, ULONG Reservrd2);
/*
Type:
typedef enum _ENUM_SETCFG_ONOFF_TYPE {
    SETCFG_ONOFF_TSSI = 0,
    SETCFG_ONOFF_DPD,
    SETCFG_ONOFF_RATEPOWER_OFFSET,
    SETCFG_ONOFF_TEMP_COMP,
    SETCFG_ONOFF_EPA_EACH_POWER,
} ENUM_SETCFG_ONOFF_TYPE, *P_ENUM_SETCFG_ONOFF_TYPE;

Control:
0:disable
1:enable

band:
0:band 0
1:band 1
*/

int WINAPI HQA_SetAPSOC_OldCmd(DWORD isUsedOld);

int WINAPI HQA_BSSInfoUpdate(ULONG functionFlag, ULONG InData0, UCHAR *pData1);
/*
typedef enum _ENUM_BSSINFO_UPDATE_TYPE {
    BSSINFO_UPDATE = 0,
    BSSINFO_UPDATE_BssIdx,
    BSSINFO_UPDATE_BSSID,
} ENUM_BSSINFO_UPDATE_TYPE, *P_ENUM_BSSINFO_UPDATE_TYPE;
*/
int WINAPI HQA_DevInfoUpdate(ULONG functionFlag, ULONG InData0, UCHAR *pData1);
/*
typedef enum _ENUM_DEVINFO_UPDATE_TYPE {
    DEVINFO_UPDATE = 0,
    DEVINFO_UPDATE_MACIDX = 0,
    DEVINFO_UPDATE_DEVMAC,
    DEVINFO_UPDATE_BAND,
} ENUM_DEVINFO_UPDATE_TYPE, *P_ENUM_DEVINFO_UPDATE_TYPE;
*/

int WINAPI HQA_TxBfTxApply(ULONG eTxBfEnable,ULONG iTxBfEnable,ULONG WlanID,ULONG isMUTx,ULONG Reserved1,ULONG Reserved2);
/*
eTxBfEnable:
0:disable eBF
1:enable eBF

iTxBfEnable:
0:disable iBF
1:enable iBF

WlanID:0~127
*/

int WINAPI HQA_TXBFProfileTagWriteExt(ULONG functionFlag, ULONG InData0, ULONG InData1, ULONG InData2, ULONG InData3,
    ULONG InData4, ULONG InData5, ULONG InData6, ULONG InData7);
//InputDate sequence: (All 4bytes)
/*7615
Flag define:
MT7615TXBFPROFILETAG_RW, ProfileIdx
MT7615TXBFPROFILETAG_INVALID = 0, //INVALID    0: default, 1: This profile number is invalid by SW
MT7615TXBFPROFILETAG_PFMUIDX, //PFMUIDX 0~63
MT7615TXBFPROFILETAG_BFTYPE, //BFTYPE 0: iBF; 1: eBF
MT7615TXBFPROFILETAG_BW, BW 0/1/2/3: BW20/40/80/160NC
MT7615TXBFPROFILETAG_SUMU, //SUMU 0: SU; 1: MU
MT7615TXBFPROFILETAG_MEMALLOC,//ColIdx0,RowIdx0,ColIdx1,RowIdx1,ColIdx2,RowIdx2,ColIdx3,RowIdx3
MT7615TXBFPROFILETAG_MATRIX,//Nrow,Ncol,Ngroup,LM,CodeBook,HtcExist
MT7615TXBFPROFILETAG_SNR, //SNR0,SNR1,SNR2,SNR3
MT7615TXBFPROFILETAG_SMTANT, //SMTANTCfg
MT7615TXBFPROFILETAG_SEIDX, //SEIDX
MT7615TXBFPROFILETAG_RMSDTHRD, //RMSDTHRD
MT7615TXBFPROFILETAG_MCSTHRD,//mcsLss0,mcsSss0,mcsLss1,mcsSss1,mcsLss2,mcsLss2
MT7615TXBFPROFILETAG_TIMEOUT, //TIMEOUT
MT7615TXBFPROFILETAG_DESIREDBW, //DESIREDBW
MT7615TXBFPROFILETAG_DESIREDNC, //DESIREDNC
MT7615TXBFPROFILETAG_DESIREDNR, //DESIREDNR

*/
int WINAPI HQA_TXBFProfileTagReadExt(ULONG functionFlag, ULONG InData0, ULONG *pOutData0, ULONG *pOutData1, ULONG *pOutData2, ULONG *pOutData3,
    ULONG *pOutData4, ULONG *pOutData5, ULONG *pOutData6, ULONG *pOutData7);
/*
typedef enum _ENUM_7615TXBFPROFILETAGWRITE_TYPE {
    MT7615TXBFPROFILETAG_RW = 0,
    MT7615TXBFPROFILETAG_SET_WLANID,
    MT7615TXBFPROFILETAG_SET_fgBFer,//1:BFer, 2:BFee
    MT7615TXBFPROFILETAG_INVALID,
    MT7615TXBFPROFILETAG_PFMUIDX,
    MT7615TXBFPROFILETAG_BFTYPE,
    MT7615TXBFPROFILETAG_BW,
    MT7615TXBFPROFILETAG_SUMU,
    MT7615TXBFPROFILETAG_MEMALLOC,//ColIdx0,RowIdx0,ColIdx1,RowIdx1,ColIdx2,RowIdx2,ColIdx3,RowIdx3
    MT7615TXBFPROFILETAG_MATRIX,//Nrow,Ncol,Ngroup,LM,CodeBook,HtcExist
    MT7615TXBFPROFILETAG_SNR,
    MT7615TXBFPROFILETAG_SMTANT,
    MT7615TXBFPROFILETAG_SEIDX,
    MT7615TXBFPROFILETAG_RMSDTHRD,
    MT7615TXBFPROFILETAG_MCSTHRD,
    MT7615TXBFPROFILETAG_TIMEOUT,
    MT7615TXBFPROFILETAG_DESIREDBW,
    MT7615TXBFPROFILETAG_DESIREDNC,
    MT7615TXBFPROFILETAG_DESIREDNR,
} ENUM_7615TXBFPROFILETAGWRITE_TYPE, *P_ENUM_7615TXBFPROFILETAGWRITE_TYPE;
*/

int WINAPI  HQA_StaRecCmmUpdate(ULONG functionFlag, ULONG InData0,UCHAR *pInData1);
/*typedef enum _ENUM_7615STA_REC_COMM_UPDATE_TYPE {
    MT7615STA_REC_COMM_UPDATE = 0,
    MT7615STA_REC_COMM_UPDATE_WLANIDX,
    MT7615STA_REC_COMM_UPDATE_BSSIDX,
    MT7615STA_REC_COMM_UPDATE_AID,
    MT7615STA_REC_COMM_UPDATE_MAC,
} ENUM_7615STA_REC_COMM_UPDATE_TYPE, *P_ENUM_7615STA_REC_COMM_UPDATE_TYPE;*/
int WINAPI  HQA_StaRecBfUpdate(ULONG functionFlag, ULONG InData0, ULONG InData1, ULONG InData2, ULONG InData3);
/*
typedef enum _ENUM_STA_REC_BF_UPDATE_TYPE {
    STA_REC_BF_UPDATE = 0,
    STA_REC_BF_UPDATE_WLANIDX,
    STA_REC_BF_UPDATE_BSSIDX,
    STA_REC_BF_UPDATE_PFMUID,
    STA_REC_BF_UPDATE_SUMU,
    STA_REC_BF_UPDATE_ETxBfCa,
    STA_REC_BF_UPDATE_NdpaRate,
    STA_REC_BF_UPDATE_NdpRate,
    STA_REC_BF_UPDATE_ReptPollRate,
    STA_REC_BF_UPDATE_TxMode,
    STA_REC_BF_UPDATE_Nc,
    STA_REC_BF_UPDATE_Nr,
    STA_REC_BF_UPDATE_CBW,
    STA_REC_BF_UPDATE_TotMemRequire,
    STA_REC_BF_UPDATE_MemRequire20M,
    STA_REC_BF_UPDATE_MemRow0_Col0,
    STA_REC_BF_UPDATE_MemRow1_Col1,
    STA_REC_BF_UPDATE_MemRow2_Col2,
    STA_REC_BF_UPDATE_MemRow3_Col3,
} ENUM_STA_REC_BF_UPDATE_TYPE, *P_ENUM_STA_REC_BF_UPDATE_TYPE;
*/
//InputDate sequence: (All 4bytes)WlanIdx,BssIdx,fgSU_MU,ETxBfCa,NdpaRate,NdpRate,ReptPollRate,TxMode,Nc,Nr,CBW,TotMemRequire,
//MemRequire20M,MemRow0,MemCol0T,MemRow1,MemCol1,MemRow2,MemCol2,MemRow3,MemCol3
//if retuen -1, input data length is wrong
//int WINAPI HQA_TXBFProfileDataReadExt(UCHAR *pInData, ULONG *pInDataLen,UCHAR *pOutData, ULONG *pOutDataLen);
int WINAPI HQA_TXBFProfileDataReadExt(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
//7615
/*
typedef enum _ENUM_7615TXBFPROFILEREAD_TYPE {
    MT7615TXBFPROFILE_READ = 0,
    MT7615TXBFPROFILE_READ_SET_PROFILEIDX,
    MT7615TXBFPROFILE_READ_SET_BFTYPE,//1:eBF, 2:iBF
    MT7615TXBFPROFILE_READ_SET_FGPFER,
    MT7615TXBFPROFILE_READ_SET_SUBCARRIER_BEG,//driver take care, getsubcarrier from
    MT7615TXBFPROFILE_READ_SET_SUBCARRIER_END,//driver take care, getsubcarrier end
    MT7615TXBFPROFILE_READ_GET_Phi11,// InData0 assign get subcarrier bumber.
    MT7615TXBFPROFILE_READ_GET_Psi21,
    MT7615TXBFPROFILE_READ_GET_Phi21,
    MT7615TXBFPROFILE_READ_GET_Psi31,
    MT7615TXBFPROFILE_READ_GET_Phi31 ,
    MT7615TXBFPROFILE_READ_GET_Psi41,
    MT7615TXBFPROFILE_READ_GET_Phi22,
    MT7615TXBFPROFILE_READ_GET_Psi32,
    MT7615TXBFPROFILE_READ_GET_Phi32,
    MT7615TXBFPROFILE_READ_GET_Psi42,
    MT7615TXBFPROFILE_READ_GET_Phi33,
    MT7615TXBFPROFILE_READ_GET_Psi43,
    MT7615TXBFPROFILE_READ_GET_SNR00,
    MT7615TXBFPROFILE_READ_GET_SNR01,
    MT7615TXBFPROFILE_READ_GET_SNR02,
    MT7615TXBFPROFILE_READ_GET_SNR03,
    MT7615TXBFPROFILE_READ_GET_u2Reserved,
} ENUM_7615TXBFPROFILEREAD_TYPE, *P_ENUM_7615TXBFPROFILEREAD_TYPE;


*/
//InputDate sequence: (All 4bytes) ProfileIndex, Subcarriers index
//OutputDate sequence: (4bytes)
/*UINT_32 u2Phi11          : 9;
UINT_32 ucPsi21          : 7;
UINT_32 u2Phi21          : 9;
UINT_32 ucPsi31          : 7;
UINT_32 u2Phi31          : 9;
UINT_32 ucPsi41          : 7;
UINT_32 u2Phi22          : 9;
UINT_32 ucPsi32          : 7;
UINT_32 u2Phi32          : 9;
UINT_32 ucPsi42          : 7;
UINT_32 u2Phi33          : 9;
UINT_32 ucPsi43          : 7;
UINT_32 u2dSNR00         : 4;
UINT_32 u2dSNR01         : 4;
UINT_32 u2dSNR02         : 4;
UINT_32 u2dSNR03         : 4;
UINT_32 u2Reserved       : 16;*/

int WINAPI HQA_TXBFProfileDataReadToFile(char *pFilePath,ULONG profileIdx,ULONG BfType,ULONG Reserved1,ULONG Reserved2);//7615
//write tag also
/*BfType:
1:Bfer
2:Bfee

*/

int WINAPI HQA_TXBFProfileDataWriteFromFile(char *pFilePath,ULONG profileIdx,ULONG Reserved0,ULONG Reserved1,ULONG Reserved2);//7615
int WINAPI HQA_TXBFProfileDataWriteExt(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
/*typedef enum _ENUM_7615TXBFPROFILEWRITE_TYPE {
    MT7615TXBFPROFILE_WRITE = 0,
    MT7615TXBFPROFILE_WRITE_SET_PROFILEIDX,
    MT7615TXBFPROFILE_WRITE_SET_SUBCARRIERIDX,
    MT7615TXBFPROFILE_WRITE_GET_Phi11,
    MT7615TXBFPROFILE_WRITE_GET_Psi21,
    MT7615TXBFPROFILE_WRITE_GET_Phi21,
    MT7615TXBFPROFILE_WRITE_GET_Psi31,
    MT7615TXBFPROFILE_WRITE_GET_Phi31 ,
    MT7615TXBFPROFILE_WRITE_GET_Psi41,
    MT7615TXBFPROFILE_WRITE_GET_Phi22,
    MT7615TXBFPROFILE_WRITE_GET_Psi32,
    MT7615TXBFPROFILE_WRITE_GET_Phi32,
    MT7615TXBFPROFILE_WRITE_GET_Psi42,
    MT7615TXBFPROFILE_WRITE_GET_Phi33,
    MT7615TXBFPROFILE_WRITE_GET_Psi43,
    MT7615TXBFPROFILE_WRITE_GET_SNR00,
    MT7615TXBFPROFILE_WRITE_GET_SNR01,
    MT7615TXBFPROFILE_WRITE_GET_SNR02,
    MT7615TXBFPROFILE_WRITE_GET_SNR03,
    MT7615TXBFPROFILE_WRITE_GET_u2Reserved,
} ENUM_7615TXBFPROFILEWRITE_TYPE, *P_ENUM_7615TXBFPROFILEWRITE_TYPE;*/
//7615
//InputDate sequence: (All 4bytes)ProfileIndex, Subcarriers index
// u2Phi11,ucPsi21,u2Phi21,ucPsi31,u2Phi31,ucPsi41,u2Phi22,ucPsi32,u2Phi32,ucPsi42
//u2Phi33,ucPsi43,u2dSNR00,u2dSNR01,u2dSNR02,u2dSNR03,u2Reserved

int WINAPI HQA_TXBFProfileDataWriteAllExt(ULONG BW, ULONG ProfileIdx, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);//no use now
//7615
//InputDate sequence: (Total 8 bytes)(All 4bytes)BW, Profile index

int WINAPI HQA_TXBFSoundingStart(ULONG functionFlag, ULONG InData0, ULONG InData1, ULONG InData2, ULONG InData3);
//7615
/*
typedef enum _ENUM_SOUNDING_START_TYPE {
    SOUNDING_START = 0,
    SOUNDING_START_SndInterval,
    SOUNDING_START_Su_Mu,
    SOUNDING_START_MuNum,
    SOUNDING_START_WlanId0,
    SOUNDING_START_WlanId1,
    SOUNDING_START_WlanId2,
    SOUNDING_START_WlanId3,
    SOUNDING_START_BAND,//for enable TMAC, not related to HAL
} ENUM_SOUNDING_START_TYPE, *P_ENUM_SOUNDING_START_TYPE;
*/
int WINAPI HQA_TXBFSoundingStop(ULONG Reserved0, ULONG Reserved1, ULONG Reserved2, ULONG Reserved3);
//7615
/*
typedef enum _ENUM_SOUNDING_STOP_TYPE {
    SOUNDING_STOP = 0,
} ENUM_SOUNDING_STOP_TYPE, *P_ENUM_SOUNDING_STOP_TYPE;
*/

int WINAPI HQA_ManualAssociation(ULONG functionFlag, ULONG InData0, UCHAR *pInUchData, ULONG *pOutData0);
/*
typedef enum _ENUM_MANUALL_ASSOCIATION {
    MANUALL_ASSOCIATION = 0,
    MANUALL_ASSOCIATION_SET_OWNMAC,
    MANUALL_ASSOCIATION_SET_TYPE,
    MANUALL_ASSOCIATION_SET_WTBL,
    MANUALL_ASSOCIATION_SET_MODE,
    MANUALL_ASSOCIATION_SET_BW,
    MANUALL_ASSOCIATION_SET_PFMUID,
    MANUALL_ASSOCIATION_SET_PHYMODE,
    MANUALL_ASSOCIATION_SET_RATE,
    MANUALL_ASSOCIATION_SET_MAC,
} ENUM_MANUALL_ASSOCIATION, *P_MANUALL_ASSOCIATION;
*/



int WINAPI HQA_MUAPInit(char *pFileName,BOOL bBatchTest);
int WINAPI HQA_MUStaInit(int Sta,char *pFileName);
int WINAPI HQA_MUBatchTest(char *pCfgFileList,char *pResultFileName);
int WINAPI HQA_MUCalInitMCS(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
/*
typedef enum _ENUM_MU_CALINIT_MCS_TYPE {
    MU_CALINIT_MCS = 0,
    MU_CALINIT_MCS_GROUP_TABLE_IDX,
    MU_CALINIT_MCS_GROUP_NUM_TXER,
} ENUM_7615_MU_CALINIT_MCS_TYPE, *P_ENUM_7615_MU_CALINIT_MCS_TYPE;
*/

int WINAPI HQA_MUGetInitMCS(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
//7615
/*
typedef enum _ENUM_MU_GETINIT_MCS_TYPE {
    MU_GETINIT_MCS = 0,
    MU_GETINIT_MCS_SET_GROUP_TABLE_IDX,//Set
    MU_GETINIT_MCS_User0InitMCS,
    MU_GETINIT_MCS_User1InitMCS,
    MU_GETINIT_MCS_User2InitMCS,
    MU_GETINIT_MCS_User3InitMCS,
} ENUM_MU_GETINIT_MCS_TYPE, *P_ENUM_MU_GETINIT_MCS_TYPE;
*/

int WINAPI HQA_MUCalLQ(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
//7615
/*
typedef enum _ENUM_MU_CAL_LQ_TYPE {
    MU_CAL_LQ = 0,
    MU_CAL_LQ_SET_Type,//0:Su, 1:Mu
    MU_CAL_LQ_SET_GroupTableIdx,
    MU_CAL_LQ_SET_NumTxer,//ap nsts
} ENUM_MU_CAL_LQ_TYPE, *P_ENUM_MU_CAL_LQ_TYPE;
*/

int WINAPI HQA_MUGetLQ(ULONG functionFlag, ULONG InData0, ULONG *pOutData0, ULONG *pOutData1, ULONG *pOutData2, ULONG *pOutData3, ULONG *pOutData4);
//7615
/*
typedef enum _ENUM_MU_GET_LQ_TYPE {
    MU_GET_LQ = 0,
    MU_GET_LQ_SET_Type,//0:Su, 1:Mu
    MU_GET_LQ_SET_GroupTableIdx,
    MU_GET_LQ_GET_User0,//OutData0:BPSK,OutData1:QPAK,OutData2:16QAM,OutData3:64QAM,OutData4:256QAM
    MU_GET_LQ_GET_User1,//OutData0:BPSK,OutData1:QPAK,OutData2:16QAM,OutData3:64QAM,OutData4:256QAM
    MU_GET_LQ_GET_User2,//OutData0:BPSK,OutData1:QPAK,OutData2:16QAM,OutData3:64QAM,OutData4:256QAM
    MU_GET_LQ_GET_User3,//OutData0:BPSK,OutData1:QPAK,OutData2:16QAM,OutData3:64QAM,OutData4:256QAM
} ENUM_MU_GET_LQ_TYPE, *P_ENUM_MU_GET_LQ_TYPE;
*/

int WINAPI HQA_MUCompareLQFromFile(char *fileName);//call this file after HQA_MUGetLQ
int WINAPI HQA_MUCompareQDFromFile(char *fileName);//call this file after HQA_MUGetQD
int WINAPI HQA_MUCompareMCSFromFile(char *fileName);//call this file after HQA_MUGetAutoMCS

int WINAPI HQA_MUSetZeroNss(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
//7615
/*
typedef enum _ENUM_MU_SET_ZERO_NSS_TYPE {
    MU_SET_ZERO_NSS = 0,
    MU_SET_ZERO_NSS_VALUE,    //each user for each bit,
} ENUM_MU_CAL_LQ_TYPE, *P_ENUM_MU_CAL_LQ_TYPE;
*/
int WINAPI HQA_MUSetSNROffset(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
//7615
/*
typedef enum _ENUM_MU_SET_SNROFFSET_TYPE {
    MU_SET_SNR_OFFSET = 0,
    MU_SET_SNR_OFFSET_VALUE,
} ENUM_MU_SET_SNROFFSET_TYPE, *P_ENUM_MU_SET_SNROFFSET_TYPE;
*/
int WINAPI HQA_MUSetSpeedUpLQ(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
/*
typedef enum _ENUM_MU_SET_SPEEDUP_LQ_TYPE {
    MU_SET_SPEEDUP_LQ = 0,
    MU_SET_SPEEDUP_LQ_VALUE,
} ENUM_MU_SET_SPEEDUP_LQ_TYPE, *P_ENUM_MU_SET_SPEEDUP_LQ_TYPE;
*/
//7615
int WINAPI HQA_MUSetMUTable(ULONG functionFlag, ULONG InData0, ULONG InData1, ULONG InData2, ULONG InData3, ULONG InData4, ULONG InData5,
    ULONG InData6, ULONG InData7, ULONG InData8, ULONG InData9, ULONG *pOutData0);
//7615
/*

typedef enum _ENUM_MU_SET_MU_TABLE_TYPE {
    MU_SET_SU_TABLE = 0,
    MU_SET_MU_TABLE,
    MU_SET_MU_TABLE_SU_bcc_1ss,//MCS0~9
    MU_SET_MU_TABLE_SU_bcc_2ss,//MCS0~9
    MU_SET_MU_TABLE_SU_bcc_3ss,//MCS0~9
    MU_SET_MU_TABLE_SU_ldpc_1ss,//MCS0~9
    MU_SET_MU_TABLE_SU_ldpc_2ss,//MCS0~9
    MU_SET_MU_TABLE_SU_ldpc_3ss,//MCS0~9

    MU_SET_MU_TABLE_MU_bcc_11_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_12_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_21_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_22_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_111_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_121_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_211_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_1111_Nr2,//MCS0~9

    MU_SET_MU_TABLE_MU_ldpc_11_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_12_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_21_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_22_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_111_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_121_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_211_Nr2,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_1111_Nr2,//MCS0~9

    MU_SET_MU_TABLE_MU_bcc_11_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_12_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_21_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_22_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_111_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_121_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_211_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_1111_Nr3,//MCS0~9

    MU_SET_MU_TABLE_MU_ldpc_11_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_12_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_21_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_22_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_111_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_121_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_211_Nr3,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_1111_Nr3,//MCS0~9

    MU_SET_MU_TABLE_MU_bcc_11,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_12,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_21,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_22,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_111,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_121,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_211,//MCS0~9
    MU_SET_MU_TABLE_MU_bcc_1111,//MCS0~9

    MU_SET_MU_TABLE_MU_ldpc_11,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_12,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_21,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_22,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_111,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_121,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_211,//MCS0~9
    MU_SET_MU_TABLE_MU_ldpc_1111,//MCS0~9
} ENUM_MU_SET_MU_TABLE_TYPE, *P_ENUM_MU_SET_MU_TABLE_TYPE;
*/
int WINAPI HQA_RecalDumpPrefix(char *pFilePath);
int WINAPI HQA_IQDumpPrefix(char *pFileName);
int WINAPI HQA_MUSetMUTableFromFile(char *pFilePath);

int WINAPI HQA_MUSetGroup(ULONG functionFlag, ULONG InData0,ULONG InData1, ULONG InData2, ULONG InData3, UCHAR *pData4,ULONG *pOutData0);
//7615
/*
typedef enum _ENUM_MU_SET_GROUP_TABLE_TYPE {
    MU_SET_GROUP_TABLE = 0,
    MU_SET_GROUP_TABLE_groupIndex,
    MU_SET_GROUP_TABLE_numberOfUser,
    MU_SET_GROUP_TABLE_UserLDPC,//User0~3
    MU_SET_GROUP_TABLE_UserNss,//User0~3
    MU_SET_GROUP_TABLE_gID,
    MU_SET_GROUP_TABLE_UserUP,//User0~3
    MU_SET_GROUP_TABLE_MUProfileID,//User0~3
    MU_SET_GROUP_TABLE_initMCS,//User0~3
    MU_SET_GROUP_TABLE_User0MACaddr,
    MU_SET_GROUP_TABLE_User1MACaddr,
    MU_SET_GROUP_TABLE_User2MACaddr,
    MU_SET_GROUP_TABLE_User3MACaddr,
} ENUM_MU_SET_GROUP_TABLE_TYPE, *P_ENUM_MU_SET_GROUP_TABLE_TYPE;
*/
int WINAPI HQA_MUTriggerTx(ULONG functionFlag, ULONG InData0,UCHAR *pData4,ULONG *pOutData0);
int WINAPI HQA_MUGetQD(ULONG functionFlag, ULONG InData0, ULONG *pOutData0, ULONG *pOutData1, ULONG *pOutData2, ULONG *pOutData3);
/*
typedef enum _ENUM_MU_GET_QD_TYPE {
    MU_GET_QD = 0,
    MU_GET_QD_SET_SubcarrierIdx,
    MU_GET_QD_GET_Q0,//Q00~Q03
    MU_GET_QD_GET_Q1,//Q10~Q13
    MU_GET_QD_GET_Q2,//Q20~Q23
    MU_GET_QD_GET_Q3,//Q30~Q33
} ENUM_MU_GET_QD_TYPE, *P_ENUM_MU_GET_QD_TYPE;
*/
int WINAPI HQA_MUGetQDToFile(char *pFileName);

int WINAPI HQA_MUSetEnable(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
/*
typedef enum _ENUM_MU_ENABLE_TYPE {
    MU_ENABLE = 0,
    MU_ENABLE_VALUE,
} ENUM_MU_ENABLE_TYPE, *P_ENUM_MU_ENABLE_TYPE;
*/

int WINAPI HQA_MUSetGID_UP(ULONG functionFlag, ULONG InData0, ULONG *pOutData0);
/*
typedef enum _ENUM_MU_SET_GID_UP_TYPE {
    MU_SET_GID_UP_TYPE = 0,
    MU_SET_GID_UP_TYPE_GID_VALUE,//0~63
    MU_SET_GID_UP_TYPE_UP_VALUE,//0~3
} ENUM_MU_SET_GID_UP_TYPE, *P_ENUM_MU_SET_GID_UP_TYPE;
*/
//InputDate sequence: (All 4bytes)     GID, UP

int WINAPI HQA_MUSetTxLength(ULONG User, ULONG Length, ULONG reserved0, ULONG reserved1, ULONG reserved2);

int WINAPI HQA_SetLED(ULONG ilenNo, ULONG iLdCtrl);

//For DUMP
//int WINAPI HQA_DeviceConnect();
//int WINAPI HQA_Dump(char *pFilterList, int nType);//0-All in single file; 1- Each filter each file
int WINAPI HQA_DeviceConnect(CString strIP,CString strUser, CString strPwd);
int WINAPI HQA_DeviceConnectExt(char *pstrIP,char *pstrUser, char *pstrPwd, char *pReserved0);

int WINAPI HQA_Dump(CString strFilterList, int nType);//0-All in single file; 1- Each filter each file
int WINAPI HQA_RXVDumpFromFile();
int WINAPI HQA_RecalDumpFromFile();
int WINAPI HQA_IQDumpFromFile();


int WINAPI HQA_iBFInit();
int WINAPI HQA_iBFSetValue(ULONG Action,ULONG SubAction, ULONG Value);
/*
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    Action    ||    SubAction    ||    Value &    Desc
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    0x01    ||    0x00        ||    1/0                (True / False) IbFInit
    0x02    ||    0x00        ||    1 ~ 196            (Channel)
    0x03    ||    0x00        ||    24 / 8            (MCS Rate: 4SS/2SS)
    0x04    ||    0x00        ||    0 ~ 31            (Tx Power)
    0x05    ||    0x00        ||    15 / 3            (Tx path : 4T / 2T)
    0x06    ||    0x00        ||    1                (Start )
    0x07    ||    0x00        ||    15 / 3            (Rx path : 4R / 2R)
    0x08    ||    0x00        ||    0/1/2/3/4        (LNA Gain Setting : 0-Low / 1-Middle / 2-High / 3-Middle,High / 4-Low,High)

    //iBF Phase compensation
    0x09    ||    0x01        ||    0 / 1 / 2 / 3    (Channel BW    : 20 / 40 / 80 / 160M)
    0x09    ||    0x02        ||    0 / 1            (Band Index    : Band0 / Band1)
    0x09    ||    0x03        ||    0 ~ 8            (Group Index )
    0x09    ||    0x04        ||    0 or 1            (buf or EEPROM)
    0x09    ||    0x05        ||    0 or 1            (Do nothing or clear)
    0x09    ||    0x00        ||    0 //Set into driver

    //Tx Packet with BF
    0x0a    ||    0x01        ||    0 / 1            (BF Off / BF on)
    0x0a    ||    0x02        ||    0 ~ 127            (WLAN ID)
    0x0a    ||    0x03        ||    1 ~ 255            (Number of Tx packet)
    0x0a    ||    0x00        ||    0 //Set into driver

    //iBF ProfileUpdate
    0x0b    ||    0x01        ||    0 ~ 63            (PFMU ID)
    0x0b    ||    0x02        ||    0 ~ 3            (Nr)
    0x0b    ||    0x03        ||    0 ~ 2            (Nc)
    0x0b    ||    0x00        ||    0 //Set into driver

    //eBF ProfileUpdate
    0x0c    ||    0x01        ||    0 ~ 63            (PFMU ID)
    0x0c    ||    0x02        ||    0 ~ 3            (Nr)
    0x0c    ||    0x03        ||    0 ~ 2            (Nc)
    0x0c    ||    0x00        ||    0 //Set into driver

    //iBF GdCal
    0x0d    ||    0x01        ||    0 ~ 8            (Group index)
    0x0d    ||    0x02        ||    0/1/2            (L/M/H channel in group)
    0x0d    ||    0x03        ||    1/0                (True/False)
    0x0d    ||    0x04        ||    0 / 1 / 2 / 3    (Do nothing / Calibration / Verification / Calibration with instrument)
    0x0d    ||    0x05        ||    0 / 1/ 2        (LNA Gain level : Low / middle / High)
    0x0d    ||    0x00        ||    0 //Set into driver

    //iBF GdVerify
    0x0e    ||    0x01        ||    0 ~ 8            (Group index)
    0x0e    ||    0x02        ||    0/1/2            (L/M/H channel in group)
    0x0e    ||    0x03        ||    0 / 1 / 2 / 3    (Do nothing / Calibration / Verification / Calibration with instrument)
    0x0e    ||    0x04        ||    0 / 1 / 2        (LNA Gain level : Low / middle / High)
    0x0e    ||    0x05        ||    0 / 1            (calibrated phase is from : Buf / EEPROM)
    0x0e    ||    0x00        ||    0 //Set into driver

    //iBF GdInit
    0x0f    ||    0x00        ||    1 / 0            (True / false)

    //iBF Phase E2p Update
    0x10    ||    0x01        ||    0 ~ 8            (Group index)
    0x10    ||    0x02        ||    1/0                (True/False)
    0x10    ||    0x03        ||    1/2/3            (Just one group / Update all of groups / Erase memory for all of groups)
    0x10    ||    0x00        ||    0 //Set into driver

*/

int WINAPI HQA_iBFGetStatus(ULONG *pOutData0, ULONG *pOutData1,ULONG *pOutData2,ULONG *pOutDataRes3,ULONG *pOutDataRes4);
int WINAPI HQA_iBFChanProfUpdate(ULONG PfmuID, ULONG SubCarIdx, ULONG Update, ULONG H11,ULONG H11Ang, ULONG H21,ULONG H21Ang, ULONG H31,ULONG H31Ang, ULONG H41,ULONG H41Ang,ULONG Reserved1,ULONG Reserved2);
//int WINAPI HQA_iBFChanAllProfUpdate(ULONG PfmuID, ULONG Res1,ULONG Res2,ULONG Res3,ULONG Res4, ULONG SubCar[64][5]);
int WINAPI HQA_iBFChanAllProfUpdate(DWORD *pData,int DataLength);
int WINAPI HQA_iBFProfileRead(ULONG ProfIdx, ULONG SubCarIdx,ULONG *pPhi1, ULONG *pPhi2,ULONG *pPhi3,ULONG *pPsi1,ULONG *pPsi2,ULONG *pPsi3);


//

//7603
/*
ilenNo: 0
iLdCtrl:
0; Solid On",
1; Solid off",
2; TX Blinking",
3; Blinking500ms_On_500ms_Off",
4; Blinking250ms_On_250ms_Off",
5; Blinking170ms_On_170ms_Off",
6; Blinking500ms_On_100ms_Off",
7; Blinking500ms_On_700ms_Off",
16; 3 Blink/per for 4s",
17; 5s on 3s off then Blinking ",
18; 5s on",
31; Generic fixblinking format",
32; Two led interactive blinking"
*/

int WINAPI SLT_OpenAdapter();
int WINAPI SLT_CloseAdapter();
int WINAPI SLT_RadioOn();
int WINAPI SLT_RadioOff();
// 2. Tx/Rx Test
int WINAPI SLT_StartTx(ULONG PacketCount/*TxCount*/,
                                    USHORT PacketSize/*TxLength*/);
int WINAPI SLT_StartRx();
int WINAPI SLT_StopTx();
int WINAPI SLT_StopRx();
int WINAPI SLT_SetTxPath(UCHAR TxPath);
int WINAPI SLT_SetRxPath(UCHAR RxPath);
int WINAPI SLT_SetTxIPG(ULONG TxIPG);
int WINAPI SLT_SetTxPower0(CHAR TxPower0);
int WINAPI SLT_SetTxPower1(CHAR TxPower1);
int WINAPI SLT_AntennaSel(UCHAR AntSel);

// 3. Channel/Preamble/Rate/... setting
int WINAPI SLT_SetChannel(UCHAR Channel);
int WINAPI SLT_SetPreamble(UCHAR Preamble);
int WINAPI SLT_SetRate(UCHAR McsRate);
int WINAPI SLT_SetNss(UCHAR Nss);
int WINAPI SLT_SetSystemBW(UCHAR SysBW);
int WINAPI SLT_SetPerPktBW(UCHAR PerPktBW);
int WINAPI SLT_SetPrimaryBW(UCHAR PrimaryBW);
int WINAPI SLT_SetFreqOffset(UCHAR FreqOffset);

// 4. Statistics Counter
int WINAPI SLT_ResetTxRxCounter();
int WINAPI SLT_GetStatistics(CHAR StatisticsBuffer[], int BufferSize);
int WINAPI SLT_GetRxOKData(ULONG *RxOKDataPacket);
int WINAPI SLT_GetRxU2MData(ULONG *RxU2MDataPacket);
int WINAPI SLT_GetTxTransmitted(ULONG *TxTransmittedCounter);

// 5. SLT test
int WINAPI SLT_SecuritySetting(PUCHAR PeerMAC, UCHAR CipherAlg);
int WINAPI SLT_SetTxAddr(void *TxFrames);
int WINAPI SLT_GetCurrentAddr(UCHAR* Addr);
int WINAPI SLT_SetSLTMode(BOOL bSLTMode);
int WINAPI SLT_GetRxRSSI(LONG *RxRSSI);
//int WINAPI SLT_GetRxSNR(double *RxSNR);
int WINAPI SLT_GetRxSNR(int *RxSNR0,int *RxSNR1);
int WINAPI SLT_SetTXRXLoopback(BOOL LoopbackMode,int iRingOrPipe);
int WINAPI SLT_ReadEEPROM(USHORT Offset, USHORT Length, PUSHORT Data);
int WINAPI SLT_SetDeviceType(int iDeviceType);
int WINAPI SLT_CalibrationResultDump(int iType,BOOL bCheckResult);
int WINAPI SLT_GetRXStatisticsAll(RX_STASTIC *pData);
int WINAPI SLT_MacRegReadAuto(ULONG Offset, ULONG* Data);
int WINAPI SLT_MacRegWriteAuto(ULONG Offset, ULONG Data);
int WINAPI SLT_SecuritySettingExt(void *pSetting);
int WINAPI SLT_FWPacketCMD_AccessEfuse(ULONG address,ULONG *setData,BOOL bIsSet,int iLength);//BOOL IsSet,0:Query, 1:set.
int WINAPI SLT_eFuseLogicalRead(DWORD *dWData0, DWORD *dWData1,DWORD *dWData2,DWORD *dWData3,DWORD dAddr);//read whole block 16 byte
int WINAPI SLT_GetRSSI(int *RxRSSI0,int *RxRSSI1);
int WINAPI SLT_SetLoadBufferbinFileName(CHAR *pFileName);
int WINAPI SLT_SetLDPC(BOOL bEnable);
int WINAPI SLT_SetGetCollectRSSINum(int iCollectnum);
int WINAPI SLT_GetCollectRSSIAvg(int *ipNum,int *ipRSSI);
DWORD WINAPI SLT_GetChipID();
int WINAPI SLT_FWPacketCMD_AccessReg(ULONG address,ULONG *setData,BOOL bIsSet);//BOOL IsSet,0:Query, 1:set.int WINAPI HQA_FWPacketCMD_AccessReg(ULONG address,ULONG *setData,BOOL bIsSet);//BOOL IsSet,0:Query, 1:set.
int WINAPI SLT_SetDriverIndex(int iIndex);
int WINAPI SLT_ExternalRegisterSetting(void);
int WINAPI SLT_SetScriptFileName(char *filename);
int WINAPI SLT_SetUartConfig(PUART_CFG_STRUC * UartConfig);
int WINAPI SLT_HQAMCUTest(ULONG TestID);
int WINAPI HQA_SetTxPowerEval();
int WINAPI HQA_SetLogOnOff(ULONG Band, ULONG Type, ULONG OnOff, ULONG BufferSize, ULONG Reserved0, ULONG Reserved1);
/*
pBufferSize;
save packet count

typedef enum _ENUM_LOG_ONOFF_TYPE {
    LOG_ONOFF = 0,
    LOG_ONOFF_RXV,
    LOG_ONOFF_RDD,
    LOG_ONOFF_RECAL,
} ENUM_LOG_ONOFF_TYPE, *P_ENUM_LOG_ONOFF_TYPE;
*/
int WINAPI HQA_GetTxPower(ULONG CurChannel,ULONG Band, ULONG *pAddress, ULONG *Value, ULONG *ChannelBand, ULONG *Reserved1);
int WINAPI HQA_GetFreqOffset(ULONG *FreqOffset,ULONG *Reserved0,ULONG *Reserved1,ULONG *Reserved2);
int WINAPI HQA_RxFilterPktLen(ULONG Band,ULONG Control, ULONG PktLen,ULONG *Reserved0,ULONG *Reserved1,ULONG *Reserved2);
/*
Band:
0:Band0
1:Band1

Control:
0:disable
1:enable

PktLen:
packet length value

*/

int WINAPI HQA_SetWiFiSpectrum(ULONG Control,ULONG Trigger, ULONG RingCapEn, ULONG TriggrtEvt, ULONG CaptureNode, ULONG CaptureStopLen,
    ULONG CaptureStopCycle, ULONG BW,ULONG *pStartAddr1,ULONG *pStartAddr2,ULONG *pStartAddr3,ULONG *pEndAddr,ULONG *pStopAddr,
    ULONG *pWrap,ULONG MacTriggerEvt,UCHAR *pTriggerMacAddr,ULONG TriggerBand);
/*
return value:
0:ok
1:wait
2:fail


Control:
1:Set wifi spectrum
2:Get wifi spectrum

Trigger:
0:Don't capture data
1:Capture Data

RingCapEn:
0:Disable Ring capture
1:Enable Ring capture


TriggerEventIdx:
typedef enum _WIFI_SPECTRUM_TRIGGEREVENT_IDX {
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_intcap_trig_stop = 0,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rdd_sc_pass_is_n1,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rdd_sc_pass_is_p1,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rdd_det_edge_smaller_0,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rdd_det_edge_larger_0,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rdd_det_pulse_is_1,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_agc_bfagc_apply,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_agc_acid_hit,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rxtd_nbid_hit,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_agc_state_is_6,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_agc_pop_trig,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_cck_abort,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rxtd_ltfsync_abort,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_sig_err,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rx_fcs_err,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rxtd_pd,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rx_ebf_en,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_rx_mu_ppdu,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_intcap_trig_stop,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rdd_sc_pass_is_n1,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rdd_sc_pass_is_p1,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rdd_det_edge_smaller_0,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rdd_det_edge_larger_0,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rdd_det_pulse_is_1,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_agc_bfagc_apply,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_agc_acid_hit,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rxtd_nbid_hit,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_agc_state_is_6,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_agc_pop_trig,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_Reserved,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rxtd_ltfsync_abort,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_sig_err,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rx_fcs_err,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rxtd_pd,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rx_ebf_en,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_rx_mu_ppdu,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band0_debug_mon_15_0,
    WIFI_SPECTRUM_TRIGGEREVENT_IDX_band1_debug_mon_15_0,

} WIFI_SPECTRUM_TRIGGEREVENT_IDX, *PWIFI_SPECTRUM_TRIGGEREVENT_IDX;

GroupNodeIdx:
typedef enum _WIFI_SPECTRUM_CAPTURENODE_IDX {
    WIFI_SPECTRUM_CAPTURENODE_RXADC = 0,
    WIFI_SPECTRUM_CAPTURENODE_LNA_GAIN_IDX,
    WIFI_SPECTRUM_CAPTURENODE_LPFGAIN_IDX,
    WIFI_SPECTRUM_CAPTURENODE_WBRSSI ,
    WIFI_SPECTRUM_CAPTURENODE_IBRSSI ,
    WIFI_SPECTRUM_CAPTURENODE_DCRF ,
    WIFI_SPECTRUM_CAPTURENODE_RXFEAFIFOout ,
    WIFI_SPECTRUM_CAPTURENODE_FDIQCout ,
    WIFI_SPECTRUM_CAPTURENODE_FIIQCout ,
    WIFI_SPECTRUM_CAPTURENODE_DGCoutputdata,
    WIFI_SPECTRUM_CAPTURENODE_FOE ,
    WIFI_SPECTRUM_CAPTURENODE_SIG_PWR_SUM ,
    WIFI_SPECTRUM_CAPTURENODE_delay_diff_out ,
    WIFI_SPECTRUM_CAPTURENODE_delay_ba_out ,
    WIFI_SPECTRUM_CAPTURENODE_LSCE,//(for TDOE)
    WIFI_SPECTRUM_CAPTURENODE_RBIST_ErrH ,
    WIFI_SPECTRUM_CAPTURENODE_TOAE,
} WIFI_SPECTRUM_CAPTURENODE_IDX, *PWIFI_SPECTRUM_CAPTURENODE_IDX;
*/


int WINAPI HQA_GetWiFiSpectrumData(ULONG WiFiSelect,ULONG IorQ, ULONG *IQNumberCount, ULONG *Data,ULONG *Reserved0,ULONG *Reserved1,ULONG *Reserved2);


/*
Get I/Q  data
WiFiSelect: WiFiSelect 0~4, WF0~3

IorQ: 0:I data, 1:Q data



*/

int WINAPI HQA_LoadScript(char *pScriptFileName,char *LogFileName, int iRepeatCount, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);

int WINAPI HQA_SetRXVectorIdx(ULONG Band,ULONG G1Select,ULONG G2Select,ULONG Reserved0,ULONG Reserved1,ULONG Reserved2);
int WINAPI HQA_SetFAGCRssiPath(ULONG Band,ULONG Path,ULONG Reserved0,ULONG Reserved1,ULONG Reserved2);

int WINAPI HQA_FrequencyOffsetTransfer(ULONG freq, float *pfValuee,ULONG Reserved0,ULONG Reserved1);
int WINAPI HQA_SetLowPower(ULONG Enable, ULONG Reserved0,ULONG Reserved1,ULONG Reserved2);
/*
Enable:
1: goin to low power mode
0: wake up from low power mode
*/

int WINAPI HQA_SetFrequencyOffsetToBufferBin(ULONG FreqOffset, ULONG reserved0, ULONG reserved1, ULONG reserved2, ULONG reserved3);
int WINAPI HQA_SetPowerToBufferBin(ULONG Power, ULONG Channel, ULONG Band, ULONG reserved0, ULONG reserved1, ULONG reserved2, ULONG reserved3);
int WINAPI HQA_SetGolden(ULONG Type,ULONG Reserved0,ULONG Reserved1);
int WINAPI HQA_ParallelOnOff(ULONG Behavior,ULONG PowerAddr,ULONG Select, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);

int WINAPI HQA_IRRSetADC(ULONG WFSelect,ULONG CH_Freq,ULONG BW, ULONG SX, ULONG Band, ULONG RunType, ULONG FType, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);
/*
WFSelect: WF0~WF4,  each bit for each antenna
CH_Freq: channel frequency. (ULONG)

BW:
0:BANDWIDTH_20
1:BANDWIDTH_40    1
2:BANDWIDTH_80    2
3:BANDWIDTH_10    3
4:BANDWIDTH_5        4
5:BANDWIDTH_160C    5
6:BANDWIDTH_160NC    6

SX: value(ULONG)

Band: DBDC band

RunType: 0:QA, 1:ATE  //ENUM_IRR_RUNTYPE

FType: 0:FI, 1:FD  //ENUM_IRR_FTYPE

*/
int WINAPI HQA_IRRSetRxGain(ULONG PGAorLPFG,ULONG LNA,ULONG RFDGC, ULONG Band, ULONG WF, ULONG Reserved1, ULONG Reserved2);
/*
PGA/LPFG:   PGA is for MT663, LPFG is for MT7615
LNA:
    UH:5
    H:4
    M:3
    L:2
    UL:1
RFGDC: only for MT6632(0~31)
Band: DBDC band0 or band1
WF: each bit for each WF
    1:WF0
    2:WF1
    3:WF0+1
    4:WF2
    5:WF0+WF2
    ...
    8:WF3

*/

int WINAPI HQA_IRRSetTTG(ULONG TTGPower,ULONG CH_Freq,ULONG FIToneFreq, ULONG Band, ULONG SWAGC, ULONG Reserved1, ULONG Reserved2);
/*
TTGPower: 0~31
CH_Freq: channel frequency. (ULONG)
FIToneFreq: tone number, float
Band: DBDC band0 or band1
SWAGC: 0:don't do SW AGC,  1:do sw AGC
*/

int WINAPI HQA_IRRSetTurnOnTTG(ULONG TTGOnOff, ULONG Band, ULONG WF, ULONG Reserved1, ULONG Reserved2);
/*
TTGOnOff: 0:off,  1:on
Band: DBDC band0 or band1
WF: each bit for each WF
    1:WF0
    2:WF1
    3:WF0+1
    4:WF2
    5:WF0+WF2
    ...
    8:WF3
*/

int WINAPI HQA_IRRLoadTestFile(char* pFilePathName, ULONG SavePattern, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);
/*
pFilePathName: fila path + file name
SavePattern: 1: save pattern, 0: don't save pattern
*/

int WINAPI HQA_IRRCaptureData(ULONG iCaptureNode,ULONG iBW, ULONG SavePattern, ULONG WFSelect, ULONG CaptureRunTime, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);
//Capture IRR FFT data.
//SavePattern: 0:Don't save FFt data, 1:save FFt data
//CaptureRunTime: save capture to buffer 0 or 1,  0: save to buffer 0, 1: save to buffer 1.

double WINAPI HQA_IRRSingleToneCal(int cw_freq, int BW, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);
//BW : 20:BW20,  40: BW40,
int    WINAPI HQA_IRRCaptureFFTData(ULONG WFSelect, int CaptureRunTime, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);

double WINAPI HQA_IRRMultiToneCal(int BW, ULONG Reserved0, ULONG Reserved1, ULONG Reserved2);
//BW : 20:BW20,  40: BW40,

double WINAPI HQA_IRR_mul_irr_cal_in_cw(double (*cw_array)[2], int len, int BW);//only for ATE
//for call flow please follow HQA_IRRLoadTestFile FD type, dIrr = Device.m_pFFTDlg->mul_irr_cal_in_cw((double (*)[2])&dAIRRValue[0],iAindex,iBWKHz);

int WINAPI HQA_SetUartConfig();
int WINAPI HQA_OpenUartDevice();
int WINAPI HQA_CloseUartDevice();
int WINAPI HQA_InitUartConfigPara(PUART_CFG_STRUC UartConfig);

int WINAPI  HQA_MCUTest(ULONG TestID);
int WINAPI HQA_CheckEfuseAccess(ULONG Addr, UCHAR* pData, int Length, ULONG *pStatus);
int WINAPI HQA_SetFFTSettings(ULONG Action,ULONG *pOutData, float *pFloatValue,UCHAR *pCharValue,int *pIntValue);
/*
typedef enum _ENUM_FFT_SETTINGS_TYPE {
    FFT_SETTINGS_UPDATE = 0,    //0,0,0,0
    FFT_EVENT,                    //1,value,0,0,0
    FFT_NODE,                    //2,value,0,0,0
    FFT_ONCE,                    //3,value,0,0,0
    FFT_WFSELECT,                //4,value,0,0,0
    FFT_CAPTIME,                //5,0,0,0,value
    FFT_CAPSTOPLEN,                //6,value,0,0,value
    FFT_TRIGGERBAND,            //7,value,0,0,0
    FFT_TRIGGERMACADDR,            //8,0,0,Value,0
    FFT_TRIGGEREVENT,            //9,value,0,0,0
} ENUM_FFT_SETTINGS_TYPE, *P_ENUM_FFT_SETTINGS_TYPE;

FFT_EVENT Value
#define STR_FFT_FREERUN        "0x00000000:FreeRun"//event
#define STR_FFT_EBFENABLE    "0x20000000:EBFEnable"
#define STR_FFT_MURXPYLOAD    "0x08000000:MURXPyload"
#define STR_FFT_FCSERROR    "0x00000008:FCSError"
#define STR_FFT_SIGERROR    "0x00000020:SIGError"
#define STR_FFT_LTFSYNCABORT "0x08000080:LTFSYNCAbort"
#define STR_FFT_LTFSYNCABORT_MT7637 "0x00000080:LTFSYNCAbort"
#define STR_FFT_CCKABORT_MT7637        "0x00000200:CCKAbort"
#define STR_FFT_CCKABORT    "0x08000200:CCKAbort"
#define STR_FFT_AGCPOPTRIG    "0x00000800:AGCPOPTrig"
#define STR_FFT_TOAETRIG    "0x80000000:TOAETrig"
#define STR_FFT_PD            "0x00000002:PD"
#define STR_FFT_AUTO        "0x00000001:Auto"
#define STR_FFT_BFAGC        "0x00080000:BFAGC"
#define STR_FFT_RDD            "0x00200000:RDD"
#define STR_FFT_ACID        "0x00020000:ACID"
#define STR_FFT_NBID        "0x00008000:NBID"
#define STR_FFT_BT_AGC_GAIN_CHANGE        "0x02000000:BTAGCGainChange"

FFT_NODE
#define STR_NODE_ADC        "0x6:ADC"
#define STR_NODE_TOAE        "0x7:TOAE"
#define STR_NODE_FIIQ        "0x8:FIIQ"
#define STR_NODE_FDIQ        "0x9:FDIQ"
#define STR_NODE_SPECTRUM    "0xB:Spectrum"
#define STR_NODE_RBIST        "0x10:RBIST"

FFT_ONCE
//    0 - false 1- True

FFT_WFSELECT
//0 ~ 3 ( WF0    ~ WF3)

FFT_CAPTIME
FFT_CAPSTOPLEN

FFT_TRIGGERBAND
#define STR_TRIGGER_BAND0        "0x0:Trigger Band0"
#define STR_TRIGGER_BAND1        "0x1:Trigger Band1"
#define STR_TRIGGER_BAND0OR1    "0x2:Trigger Band0|1"
#define STR_TRIGGER_BAND0AND1    "0x3:Trigger Band0&1"

FFT_TRIGGEREVENT
#define STR_MAC_TRIGGEREVT_DESTADDR        "0x2000:OwnMac"
#define STR_MAC_TRIGGEREVT_SOURCEADDR    "0x20:SourceAddr"
*/


int WINAPI HQA_StartFFTCapture(BOOL bStart);
int WINAPI HQA_SetBufferBin(CHAR nBufferBin);

int WINAPI HQA_eFusePhysicalWriteExt(UCHAR *dataBuf, ULONG dataSize);

int WINAPI HQA_eFusePhysicalReadExt(UCHAR *dataBuf, ULONG dataSize);

int WINAPI HQA_eFuseLogicalWriteExt(ULONG addr, UCHAR *dataBuf, ULONG dataSize);

int WINAPI HQA_eFuseLogicalReadExt(ULONG addr, UCHAR *dataBuf, ULONG dataSize);

int WINAPI HQA_WriteDataToFlash(ULONG address, char *dataBuf, ULONG dataSize);

int WINAPI HQA_ReadDataFromFlash(ULONG address, char *dataBuf, ULONG dataSize);

BOOL WINAPI HQA_setComPortInfo(UINT32 selectPort, UINT32 selectBaudrate);

BOOL WINAPI HQA_Read86eFuse(UCHAR *dataBuf, ULONG dataSize);

BOOL WINAPI HQA_Write86eFuse(UCHAR *dataBuf, ULONG dataSize);

int WINAPI HQA_Get86eFuseLen();

BOOL WINAPI HQA_Read86eFuseItem(UINT16 offset, UCHAR *dataBuf);

BOOL WINAPI HQA_Write86eFuseItem(UINT16 offset, UCHAR dataBuf);

int WINAPI HQA_Get86eFuseMode();

BOOL WINAPI HQA_Read86TxPowerValue(UCHAR *dataBuf);

BOOL WINAPI HQA_Write86TxPowerValue(UCHAR *dataBuf);

int WINAPI HQA_Get86TxPowerMode();

int WINAPI HQA_DriverTest(UINT32 testItem, UINT32 testCmd);

int WINAPI HQA_ResetCM4(void);

int WINAPI SLT_HQADriverTest(UINT32 testDriver, UINT32 testCmd);

int WINAPI SLT_HQAResetCM4(void);

int WINAPI SLT_HQASetDownloadCallbackRetryTime(UINT32 retryTime);

/**
 * @brief Write the Customer Ctrl value to the eFuse.
 *  The eFuse offset is : 0x140
 *  The write bits : 2, 5, 8, 9, 10, 11, 12, 13, 14
 *  The other bits keep the original value.
 *
 * @param value The value wish to write to device.
 * @return int When operate succeed, return TRUE; otherwise return FALSE
 */
int WINAPI HQA_WriteCustomerCTRL(UINT32 value);

/**
 * @brief Write WLAN MAC Address to the eFuse
 *  The eFuse offset should be : 0x204 and 0x208.
 *
 * @param macAddr0  Write to eFuse offset 0x208 0 ~ 15 bits
 * @param macAddr1  Write to eFuse offset 0x204 0 ~ 15 bits
 * @param macAddr2  Write to eFuse offset 0x204 16 ~ 31 bits
 * @return int When operate succeed, return TRUE; otherwise, return FALSE
 */
int WINAPI HQA_WriteWLANMacAddr(USHORT macAddr0, USHORT macAddr1, USHORT macAddr2);

/**
 * @brief Write the WiFi Mac Address to the eFuse
 *  The eFuse offset should be : 0x204 and 0x208
 *
 * @param mac_addr The 6 bytes of the MAC Address to write to the eFuse
 *                  It should be like : 11:22:33:44:55:66 (without the colon and ordered)
 * @return int When operate succeed, return TRUE; otherwise, return FALSE
 */
int WINAPI HQA_WriteWLANMacAddr_order(unsigned char *mac_addr);

/**
 * @brief Write the BT Mac Address to the eFuse
 *  The eFuse offset should be : 0x890 and 0x894
 *
 * @param mac_addr The 6 bytes of the MAC Address to write to the eFuse
 *                  It should be like : 11:22:33:44:55:66 (without the colon and ordered)
 * @return int When operate succeed, return TRUE; otherwise, return FALSE
 */
int WINAPI HQA_WriteBTMacAddr(unsigned char *mac_addr);

/**
 * @brief Read the WiFi MAC Address from the eFuse
 *   The eFuse offset should be : 0x204 and 0x208
 * @param mac_addr The 6 bytes of the MAC address which read from the eFuse to fill in.
 *                  It should be with ordered readable (like 11:22:33:44:55:66)
 * @return int When opearte succeed, return TRUE, otherwise, return FALSE
 * */
int WINAPI HQA_ReadWLANMacAddr(unsigned char* mac_addr);

/**
 * @brief Read the BT MAC Address from the eFuse
 *   The eFuse offset should be : 0x890 and 0x894
 * @param mac_addr The 6 bytes of the MAC address which read from the eFuse to fill in.
 *                  It should be with ordered readable (like 11:22:33:44:55:66)
 * @return int When opearte succeed, return TRUE, otherwise, return FALSE
 * */
int WINAPI HQA_ReadBTMacAddr(unsigned char* mac_addr);

/**
 * @brief Write crystal trim configuration to the eFuse
 *  The eFuse offset should be : 0x230
 *  This interface only write the crystal trim 2.
 *  The valid bit should be automatically write into eFuse.
 *
 *  Note.
 *      If the crystal trim 2 valid bit (bit23) alreay been set to be valid (1), Should return FASLE.
 *      The valid bit should be written to be valid (1) automatically.
 *
 * @param value The value wish to write to eFuse
 * @return int Wqhen operate succeed, return TRUE; otherwise, return FALSE.
 */
int WINAPI HQA_WriteCrystalTrim(UCHAR value);

/**
 * @brief Write the crystal trim configuration to the eFuse
 *  The eFuse offset should be : 0x230
 *  This interface only write the crystal trim 3.
 *
 *  Note:
 *      If the crystal trim 3 valid bit (bit31) already been set to be valid (1), should return FALSE.
 *      The valid bit should be written to be valid (1) automatically.
 *
 * @param value The value wish to write to eFuse
 * @return int When operate succeed, return TRUE; otherwise, return FALSE.
 */
int WINAPI HQA_WriteCrystalTrim3(UCHAR value);

/**
 * @brief Write the ePA and eLNA eFuse to the eFuse corresponding bits.
 *  The eFuse offset should be : 0x408
 *  This interface only write the bit29 (for ePA enable) and bit28 (for eLNA enable)
 *
 *  Note:
 *      The interface should write the WIFI_EFUSE2_VALID bit to be valid.
 *      iF WIFI_EFUSE2_VALID bit is valid (bit31) already set to be valid(1), should return FALSE.
 *
 * @param ePaEnable 1 for enable; 0 for disable.
 * @param eLNAEnable 1 for enable; 0 for disable.
 * @return int When operate succeed, return TRUE; otherwise, return FALSE
 */
int WINAPI HQA_WriteePaeLNA(BOOL ePaEnable, BOOL eLNAEnable);

/**
 * @brief Write the WiFi TX power to the eFuse
 *  The eFuse offset should be : 0x410 and 0x414
 *
 * Note:
 *      The corresponding TX power valid bit should also be written to be valid.
 *      The interface should write the WIFI_EFUSE4_VALID/WIFI_EFUSE5_VALID bit to be valid.
 *      If the WIFI_EFUSE4/WIFI_EFUSE5 valid bit already been set to be valid(1), shoudl return FALSE.
 *
 * @param txpowerBase           The base power, which should be written to WIFI_EFUSE4 bit0 ~ bit7
 * @param txpowerOffLow         The offset low power, which should be written to WIFI_EFUSE4 bit8 ~ bit15
 * @param txpowerOffMiddle      The offset middle power, which should be written to WIFI_EFUSE4 bit16 ~ bit23
 * @param txpowerOffHigh        The offset high power, which should be written to WIFI_EFUSE5 bit0 ~ bit7
 * @return int When operate succeed, return TRUE; otherwise, return FALSE
 */
int WINAPI HQA_WritePowerParam(UCHAR txpowerBase, UCHAR txpowerOffLow, UCHAR txpowerOffMiddle, UCHAR txpowerOffHigh);

/**
 * @brief
 *
 * @param countryCode
 * @return int HQA_WriteCountryCode
 */
int WINAPI HQA_WriteCountryCode(UCHAR countryCode);

/**
 * @brief Write the EPA and ELNA configuration to EEPROM which only enabled when the device is running
 * Once the device is reset, the configuration should be discarded.
 * If wish to make it store forever, please call #HQA_WriteePaeLNA that should write the configuration to eFuse.
 *
 * @param bEPAStatus    for EPA enabled or not, TRUE means enable, FALSE for disable
 * @param bELNAStatus   for ELNA enabled or not, TRUE means enable, FALSE for disable
 * @return int HQA_WriteEpaElnaToFW
 */
int WINAPI HQA_WriteEpaElnaToFW(BOOL bEPAStatus, BOOL bELNAStatus);

int WINAPI HQA_ConfigGPIO(const UCHAR chPort, const UCHAR chMode, const UCHAR chDir, const UCHAR chData);

int WINAPI HQA_EnableSPI(int nID, BOOL bEnable);

int WINAPI HQA_EnableSDIO(BOOL bEnable);

/**
 * New feature - efem
 *
 * @brief Configure the efem automatically according to the configuration in the efem.ini file
 * which localted in the same folder with the HQADLL.dll
 *
 * In the efem.ini file, configured the GPIO and the annatenna selection
 *
 * @return int HQA_ConfigEFEM_Auto
 *  If execute succeed, return TRUE
 *  Otherwise, return FALSE
 */
int WINAPI HQA_ConfigEFEM_Auto();

/**
 * @brief The open adapter step enum values
 *
 */
typedef enum {
    /**
     * Start to check the comport is ready to use
     */
    OPEN_ADAPTER_STEP_CHECK_COMPORT,
    /**
     * Start to download library - ATED.bin
     */
    OPEN_ADAPTER_STEP_DOWNLOAD_BINARY,
    /**
     * Start to initialize the device
     * Write register, download N9
     */
    OPEN_ADAPTER_STEP_INITIALIZE_DEVICE,
    /**
     * Open adapter finished
     */
    OPEN_ADAPTER_STEP_DONE,

} open_adapter_step;

/**
 * @brief Open adapter step notify callback function
 *
 */
typedef void (*open_adapter_step_notify)(open_adapter_step which_step);

/**
 * @brief Set the callback to notify current running status of the function #HQA_OpenAdapter
 *
 * @param notify_callback The callback function pointer
 * @return int If set succeed, return TRUE, otherwise return FALSE
 */
int WINAPI HQA_SetOpenAdapterStepCallback(open_adapter_step_notify notify_callback);


#endif /* _HQADLL_H_ */

